"""Pool one-at-a-time ablations over the locked test set and the three repeated-split test parts."""
import json
from scipy import stats
from ofx import *
df, info = load_data(verbose=False); codes = joint_codes(df["Insomnia"], df["Anxiety"]); G = df["_profile_id"].values
key = lambda nm: "".join(c if c.isalnum() else "_" for c in nm)[:50]
exec(open("s26_ablation.py").read().split("codes = joint_codes")[0].split("S = json.load")[1].join(["S = json.load", ""])) if False else None
VN = ["A OrdiFuse (published)", "B − cross-task fusion", "C − item passthrough", "D − fusion − passthrough (plain ordinal+nominal stack)",
      "E − nominal level-0 learners (ordinal only)", "F − ordinal level-0 learners (nominal only)", "G − class weighting", "H − decision offsets",
      "I LR meta-learner instead of HGB", "J isotonic calibration layer added",
      "S1 without ISI items, with fusion", "S2 without ISI items, no fusion", "S3 without HAM-A items, with fusion", "S4 without HAM-A items, no fusion"]
SPL = [("main", None), ("rep1", 101), ("rep2", 102), ("rep3", 103)]
rng = np.random.default_rng(SEED); rows = []; per = {}
for sname, seed in SPL:
    if seed is None: _, _, tr, te = get_split()
    else: tr, te = grouped_split(len(df), codes, G, 0.20, seed)
    T = df.iloc[te].reset_index(drop=True); Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
    gt = T["_profile_id"].values; ug = np.unique(gt); gidx = {u: np.where(gt == u)[0] for u in ug}
    GB = [np.concatenate([gidx[u] for u in rng.choice(ug, len(ug))]) for _ in range(1000)]
    R = {}
    for vn in VN:
        if vn.startswith("H"):
            A = R.get("A OrdiFuse (published)")
            if A is None: continue
            pr = A[1]; R[vn] = ({t: pr[t].argmax(1) for t in TASKS}, pr); continue
        f = os.path.join(CACHE, "of24_main_test.joblib") if (sname == "main" and vn.startswith("A ")) else os.path.join(CACHE, f"abl_{sname}_{key(vn)}.joblib")
        if os.path.exists(f): R[vn] = joblib.load(f)
    if "A OrdiFuse (published)" not in R: continue
    A = R["A OrdiFuse (published)"][0]
    a_b = np.array([np.mean([macro_f1(Yt[t][i], A[t][i]) for t in TASKS]) for i in GB])
    for vn, (p, _) in R.items():
        d = a_b - np.array([np.mean([macro_f1(Yt[t][i], p[t][i]) for t in TASKS]) for i in GB])
        jc = lambda q: np.mean((q["insomnia"] == Yt["insomnia"]) & (q["anxiety"] == Yt["anxiety"]))
        rows.append({"split": sname, "variant": vn, "n": len(T), "f1_ins": macro_f1(Yt["insomnia"], p["insomnia"]), "f1_anx": macro_f1(Yt["anxiety"], p["anxiety"]),
                     "f1_mt": mt_f1(Yt, p), "joint_exact": 100 * jc(p), "delta_A_minus_variant": mt_f1(Yt, A) - mt_f1(Yt, p), "se": d.std(ddof=1)})
D = pd.DataFrame(rows); D.round(5).to_csv(os.path.join(OUT, "r23_ablation_by_split.csv"), index=False)
pool = []
for vn, g in D.groupby("variant", sort=False):
    g = g[g.se > 0]
    if len(g) == 0: continue
    w = 1 / g.se ** 2; m = (w * g.delta_A_minus_variant).sum() / w.sum(); se = np.sqrt(1 / w.sum())
    pool.append({"variant": vn, "k_sets": len(g), "mean_f1_mt": g.f1_mt.mean(), "pooled_delta": m, "lo": m - 1.96 * se, "hi": m + 1.96 * se,
                 "p": 2 * stats.norm.sf(abs(m / se)), "deltas_by_split": "; ".join(f"{s}:{v:+.4f}" for s, v in zip(g.split, g.delta_A_minus_variant))})
P = pd.DataFrame(pool); P.round(5).to_csv(os.path.join(OUT, "r23_ablation_pooled.csv"), index=False)
pd.set_option("display.width", 250); print(D.pivot(index="variant", columns="split", values="f1_mt").round(4)); print(P.round(4).to_string())
