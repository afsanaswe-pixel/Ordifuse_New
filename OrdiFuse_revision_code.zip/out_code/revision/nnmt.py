"""Neural multitask ordinal baselines (R1.7), JAX/optax, CPU.
  MT-MLP-CORAL : shared trunk MLP + two rank-consistent CORAL ordinal heads (Cao et al., 2020)
  MT-MLP-CUM   : shared trunk MLP + two cumulative-link heads with threshold-specific weights
                 (neural analogue of the Frank-Hall decomposition; monotonised by a running minimum)
  MT-MLP-SOFT  : shared trunk MLP + two softmax heads
  ST-MLP-CORAL : the same network trained separately per task (single-task control)
  MT-FTT-CORAL : compact FT-Transformer (Gorishniy et al., 2021): per-feature tokens, CLS token,
                 pre-norm Transformer blocks, two CORAL heads on the CLS representation
All losses are class-balanced (inverse-frequency weights); training uses AdamW with early stopping
on a grouped validation fold; decision offsets are tuned out of fold exactly as for OrdiFuse."""
import os
os.environ.setdefault("XLA_FLAGS", "--xla_cpu_multi_thread_eigen=true intra_op_parallelism_threads=2")
import numpy as np, jax, jax.numpy as jnp, optax
from ofx import *
from sklearn.preprocessing import StandardScaler

def encode_fit(X, feats):
    enc = make_encoder(feats).fit(X[feats]); Z = enc.transform(X[feats]).astype(np.float32)
    sc = StandardScaler().fit(Z); return (enc, sc)
def encode(E, X, feats):
    return E[1].transform(E[0].transform(X[feats])).astype(np.float32)

def glorot(key, shape):
    lim = np.sqrt(6 / (shape[0] + shape[-1])); return jax.random.uniform(key, shape, minval=-lim, maxval=lim)

# ------------------------------------------------------------------ networks
def init_mlp(key, d_in, hidden, heads, kind):
    ks = jax.random.split(key, 10); p = {"W": [], "b": []}; d = d_in
    for i, h in enumerate(hidden):
        p["W"].append(glorot(ks[i], (d, h))); p["b"].append(jnp.zeros(h)); d = h
    p["heads"] = {}
    for j, (t, Kt) in enumerate(heads):
        if kind == "coral": p["heads"][t] = {"w": glorot(ks[6 + j], (d, 1)), "b": jnp.linspace(1, -1, Kt - 1)}
        elif kind == "cum": p["heads"][t] = {"w": glorot(ks[6 + j], (d, Kt - 1)), "b": jnp.linspace(1, -1, Kt - 1)}
        else: p["heads"][t] = {"w": glorot(ks[6 + j], (d, Kt)), "b": jnp.zeros(Kt)}
    return p
def mlp_trunk(p, x, drop, key, train):
    h = x
    for i, (W, b) in enumerate(zip(p["W"], p["b"])):
        h = jax.nn.relu(h @ W + b)
        if train and drop > 0:
            key, sk = jax.random.split(key); h = h * jax.random.bernoulli(sk, 1 - drop, h.shape) / (1 - drop)
    return h

def init_ftt(key, d_in, d, n_blocks, heads, n_heads, kind):
    ks = jax.random.split(key, 8 + 6 * n_blocks)
    p = {"tok_w": jax.random.normal(ks[0], (d_in, d)) * 0.1, "tok_b": jax.random.normal(ks[1], (d_in, d)) * 0.1,
         "cls": jax.random.normal(ks[2], (1, d)) * 0.1, "blocks": [], "ln_g": jnp.ones(d), "ln_b": jnp.zeros(d)}
    for i in range(n_blocks):
        k = ks[8 + 6 * i: 14 + 6 * i]
        p["blocks"].append({"q": glorot(k[0], (d, d)), "k": glorot(k[1], (d, d)), "v": glorot(k[2], (d, d)), "o": glorot(k[3], (d, d)),
                            "f1": glorot(k[4], (d, 2 * d)), "fb1": jnp.zeros(2 * d), "f2": glorot(k[5], (2 * d, d)), "fb2": jnp.zeros(d),
                            "g1": jnp.ones(d), "b1": jnp.zeros(d), "g2": jnp.ones(d), "b2": jnp.zeros(d)})
    p["heads"] = {t: {"w": glorot(ks[3 + j], (d, 1 if kind == "coral" else (Kt - 1 if kind == "cum" else Kt))),
                      "b": (jnp.linspace(1, -1, Kt - 1) if kind != "soft" else jnp.zeros(Kt))} for j, (t, Kt) in enumerate(heads)}
    return p
def ln(x, g, b): m = x.mean(-1, keepdims=True); v = x.var(-1, keepdims=True); return (x - m) / jnp.sqrt(v + 1e-5) * g + b
def ftt_trunk(p, x, drop, key, train, n_heads):
    tok = x[:, :, None] * p["tok_w"][None] + p["tok_b"][None]               # (n, F, d)
    h = jnp.concatenate([jnp.broadcast_to(p["cls"][None], (x.shape[0], 1, p["cls"].shape[1])), tok], 1)
    n, L, d = h.shape; dh = d // n_heads
    for blk in p["blocks"]:
        z = ln(h, blk["g1"], blk["b1"])
        q = (z @ blk["q"]).reshape(n, L, n_heads, dh); k = (z @ blk["k"]).reshape(n, L, n_heads, dh); v = (z @ blk["v"]).reshape(n, L, n_heads, dh)
        a = jax.nn.softmax(jnp.einsum("nihd,njhd->nhij", q, k) / np.sqrt(dh), -1)
        if train and drop > 0:
            key, sk = jax.random.split(key); a = a * jax.random.bernoulli(sk, 1 - drop, a.shape) / (1 - drop)
        h = h + jnp.einsum("nhij,njhd->nihd", a, v).reshape(n, L, d) @ blk["o"]
        z = ln(h, blk["g2"], blk["b2"]); h = h + jax.nn.relu(z @ blk["f1"] + blk["fb1"]) @ blk["f2"] + blk["fb2"]
    return ln(h[:, 0], p["ln_g"], p["ln_b"])

def head_out(hp, h, kind):
    if kind in ("coral", "cum"): return (h @ hp["w"]) + hp["b"][None, :]           # logits of P(y>k), k=0..K-2
    return h @ hp["w"] + hp["b"]

def coral_proba(logits):
    g = jax.nn.sigmoid(logits); g = jnp.minimum(1.0, g)
    g = jax.lax.cummin(g, axis=1)
    P = jnp.concatenate([1 - g[:, :1], g[:, :-1] - g[:, 1:], g[:, -1:]], 1)
    P = jnp.clip(P, 1e-9, None); return P / P.sum(1, keepdims=True)

class NeuralMT:
    def __init__(self, feats, arch="mlp", kind="coral", tasks=TASKS, hidden=(128, 64), d=32, n_blocks=2, n_heads=4,
                 drop=0.1, lr=2e-3, wd=1e-4, epochs=150, patience=15, batch=256, seed=SEED, fixed_epochs=None):
        self.__dict__.update(dict(feats=list(feats), arch=arch, kind=kind, tasks=tuple(tasks), hidden=tuple(hidden), d=d,
                                  n_blocks=n_blocks, n_heads=n_heads, drop=drop, lr=lr, wd=wd, epochs=epochs,
                                  patience=patience, batch=batch, seed=seed, fixed_epochs=fixed_epochs))
    def _forward(self, p, x, key, train):
        if self.arch == "mlp": h = mlp_trunk(p, x, self.drop, key, train)
        else: h = ftt_trunk(p, x, self.drop, key, train, self.n_heads)
        return {t: head_out(p["heads"][t], h, self.kind) for t in self.tasks}
    def _loss(self, p, x, ys, ws, key):
        out = self._forward(p, x, key, True); L = 0.0
        for t in self.tasks:
            y, w = ys[t], ws[t]
            if self.kind in ("coral", "cum"):
                Kt = K[t]; z = (y[:, None] > jnp.arange(Kt - 1)[None]).astype(jnp.float32)
                l = optax.sigmoid_binary_cross_entropy(out[t], z).sum(1)
            else:
                l = optax.softmax_cross_entropy_with_integer_labels(out[t], y)
            L = L + (w * l).sum() / w.sum()
        return L
    def _proba(self, p, x):
        out = self._forward(p, x, None, False)
        return {t: np.asarray(coral_proba(out[t]) if self.kind in ("coral", "cum") else jax.nn.softmax(out[t], -1)) for t in self.tasks}
    def fit(self, X, Y, groups, Xval=None, Yval=None):
        X = X.reset_index(drop=True); self.E = encode_fit(X, self.feats); x = jnp.asarray(encode(self.E, X, self.feats))
        key = jax.random.PRNGKey(self.seed); key, ik = jax.random.split(key)
        heads = [(t, K[t]) for t in self.tasks]
        p = init_mlp(ik, x.shape[1], self.hidden, heads, self.kind) if self.arch == "mlp" else init_ftt(ik, x.shape[1], self.d, self.n_blocks, heads, self.n_heads, self.kind)
        ys = {t: jnp.asarray(Y[t]) for t in self.tasks}
        cw = {t: (len(Y[t]) / (K[t] * np.bincount(Y[t], minlength=K[t]))) for t in self.tasks}
        ws = {t: jnp.asarray(cw[t][Y[t]], dtype=jnp.float32) for t in self.tasks}
        opt = optax.adamw(self.lr, weight_decay=self.wd); st = opt.init(p)
        @jax.jit
        def step(p, st, xb, yb, wb, k):
            l, gr = jax.value_and_grad(self._loss)(p, xb, yb, wb, k); u, st = opt.update(gr, st, p); return optax.apply_updates(p, u), st, l
        if Xval is not None:
            xv = jnp.asarray(encode(self.E, Xval.reset_index(drop=True), self.feats))
        n = len(Y[self.tasks[0]]); rng = np.random.default_rng(self.seed)
        best, best_p, best_ep, wait = -1, p, 0, 0; n_ep = self.fixed_epochs or self.epochs; self.curve_ = []
        for ep in range(n_ep):
            perm = rng.permutation(n)
            for i in range(0, n, self.batch):
                b = perm[i:i + self.batch]; key, sk = jax.random.split(key)
                p, st, _ = step(p, st, x[b], {t: ys[t][b] for t in self.tasks}, {t: ws[t][b] for t in self.tasks}, sk)
            if Xval is not None and self.fixed_epochs is None:
                pv = self._proba(p, xv); s = np.mean([macro_f1(Yval[t], pv[t].argmax(1)) for t in self.tasks]); self.curve_.append(s)
                if s > best + 1e-5: best, best_p, best_ep, wait = s, p, ep + 1, 0
                else:
                    wait += 1
                    if wait >= self.patience: break
        self.p_ = best_p if (Xval is not None and self.fixed_epochs is None) else p
        self.best_epoch_ = best_ep if Xval is not None else n_ep; self.best_val_ = best
        return self
    def proba(self, X):
        return self._proba(self.p_, jnp.asarray(encode(self.E, X.reset_index(drop=True), self.feats)))
