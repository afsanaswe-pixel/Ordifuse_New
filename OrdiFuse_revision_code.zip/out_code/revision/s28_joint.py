"""R2.2 joint (both-task) exact-match accuracy on the locked test set, with profile-group bootstrap CIs and paired
tests (exact McNemar on joint correctness; Holm over the pre-declared family)."""
import json, glob
from scipy import stats
from ofx import *
df, info, tr, te = get_split(); T = df.iloc[te].reset_index(drop=True)
Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
key = lambda nm: "".join(c if c.isalnum() else "_" for c in nm)[:60]
NAMES = ["OrdiFuse (24)", "OrdiFuse without cross-task fusion (24)", "OrdiFuse previous configuration V0 (24)",
         "Stacking comparator, grid-selected (24)", "Stacking comparator, class-balanced + offsets (24)",
         "HGB class-balanced, default (24)", "LightGBM tuned + offsets (24)", "OrdiFuse (51)"]
P = {}
for nm in NAMES:
    f = os.path.join(CACHE, "cmp_" + key(nm) + ".joblib")
    if os.path.exists(f): P[nm] = joblib.load(f)[0]
for nn in ["MT-MLP-CUM", "MT-MLP-SOFT", "MT-MLP-CORAL", "MT-FTT-CUM"]:
    f = os.path.join(CACHE, f"nn_eval_{nn}.joblib")
    if os.path.exists(f): P[f"Neural {nn} (24)"] = joblib.load(f)["pred"]
f = os.path.join(CACHE, "nn_eval_ST_MT-MLP-CUM.joblib")
if os.path.exists(f): P["Neural single-task twin of MT-MLP-CUM (24)"] = joblib.load(f)["pred"]
P["Published cut-off rule"] = {"insomnia": np.digitize(T["ISI_total"], [7, 14, 21], right=True), "anxiety": np.digitize(T["HAMA_total"], [13, 17, 24, 30], right=True)}
gt = T["_profile_id"].values; ug = np.unique(gt); gidx = {u: np.where(gt == u)[0] for u in ug}
rng = np.random.default_rng(SEED); GB = [np.concatenate([gidx[u] for u in rng.choice(ug, len(ug))]) for _ in range(2000)]
def jc(p): return (p["insomnia"] == Yt["insomnia"]) & (p["anxiety"] == Yt["anxiety"])
def w1(p): return (np.abs(p["insomnia"] - Yt["insomnia"]) <= 1) & (np.abs(p["anxiety"] - Yt["anxiety"]) <= 1)
rows = []
for nm, p in P.items():
    j = jc(p); bs = [j[i].mean() for i in GB]
    ci, ca = p["insomnia"] == Yt["insomnia"], p["anxiety"] == Yt["anxiety"]
    rows.append({"model": nm, "f1_ins": macro_f1(Yt["insomnia"], p["insomnia"]), "f1_anx": macro_f1(Yt["anxiety"], p["anxiety"]), "f1_mt": mt_f1(Yt, p),
                 "acc_ins": 100 * ci.mean(), "acc_anx": 100 * ca.mean(), "mean_of_two_acc": 100 * (ci.mean() + ca.mean()) / 2,
                 "joint_exact": 100 * j.mean(), "joint_lo": 100 * np.percentile(bs, 2.5), "joint_hi": 100 * np.percentile(bs, 97.5),
                 "joint_within_one": 100 * w1(p).mean(), "n_both_wrong": int((~ci & ~ca).sum()),
                 "expected_joint_if_independent": 100 * ci.mean() * ca.mean()})
R = pd.DataFrame(rows).sort_values("joint_exact", ascending=False); R.round(4).to_csv(os.path.join(OUT, "r22_joint_exact.csv"), index=False)
print(R.round(3).to_string(index=False))
ref = jc(P["OrdiFuse (24)"]); pr = []
for nm in P:
    if nm == "OrdiFuse (24)": continue
    b = jc(P[nm]); n01, n10 = int((ref & ~b).sum()), int((~ref & b).sum())
    p = stats.binomtest(n01, n01 + n10, 0.5).pvalue if n01 + n10 else 1.0
    d = [ref[i].mean() - b[i].mean() for i in GB]
    pr.append({"comparator": nm, "delta_joint_pp": 100 * (ref.mean() - b.mean()), "lo": 100 * np.percentile(d, 2.5), "hi": 100 * np.percentile(d, 97.5),
               "OrdiFuse_only_correct": n01, "comparator_only_correct": n10, "exact_mcnemar_p": p})
PR = pd.DataFrame(pr); m = len(PR); o = np.argsort(PR["exact_mcnemar_p"].values); h = np.zeros(m); run = 0
for r, i in enumerate(o): run = max(run, min(1, (m - r) * PR["exact_mcnemar_p"].values[i])); h[i] = run
PR["holm_p_all"] = h; PR.round(5).to_csv(os.path.join(OUT, "r22_joint_paired.csv"), index=False); print(PR.round(4).to_string(index=False))
