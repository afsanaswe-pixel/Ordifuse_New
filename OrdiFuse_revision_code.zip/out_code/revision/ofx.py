"""OrdiFuse short-form study — shared library (data, encoders, models, metrics).

Leakage rules enforced everywhere:
  * one grouped (duplicate-aware), joint-stratified 80/20 split; the test partition is
    read only by final_eval.py, after every choice has been frozen;
  * every ranking, subset choice, model-design choice and threshold is fitted on the
    training partition (grouped inner CV) only.
"""
import os, json, time, hashlib, warnings
warnings.filterwarnings("ignore")
os.environ.setdefault("OMP_NUM_THREADS", "2")
import numpy as np, pandas as pd, joblib
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (RandomForestClassifier, ExtraTreesClassifier,
                              HistGradientBoostingClassifier, GradientBoostingClassifier)
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (f1_score, cohen_kappa_score, roc_auc_score, accuracy_score,
                             mean_absolute_error)

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.environ.get("OF_DATA", os.path.join(HERE, "data.xlsx"))
CACHE = os.path.join(HERE, "cache"); os.makedirs(CACHE, exist_ok=True)
OUT = os.path.join(HERE, "out"); os.makedirs(OUT, exist_ok=True)
SEED, TEST_SIZE, N_JOBS = 42, 0.20, 2

# ----------------------------------------------------------------------------- data
SOCIO = ["Gender", "Age", "LivingStatus", "Occupation", "EducationalYear", "MaritalStatus",
         "SmokingHabit", "Alcohol", "Place_of_Education", "UniversityType", "SleepTime"]
COMO = ["Asthma", "Hypertension", "HeartDisease", "Arthritis", "Cancer", "Diabetes"]
ISI = [f"ISI{i}" for i in range(1, 8)]
HAMA = [f"HAM{i}" for i in range(1, 15)]
AD = [f"AD{i}" for i in range(1, 14)]
DOMAINS = {"SOCIO": SOCIO, "COMO": COMO, "ISI": ISI, "HAMA": HAMA, "AD": AD}
FEATURES = SOCIO + COMO + ISI + HAMA + AD
VAR_DOMAIN = {v: d for d, vs in DOMAINS.items() for v in vs}
TASKS = ("insomnia", "anxiety")
K = {"insomnia": 4, "anxiety": 5}

CODES = {
    "Gender": {"Male": 0, "Female": 1, "Third": 2},
    "Age": {"<18": 0, "18-23": 1, "24-28": 2, ">28": 3},
    "LivingStatus": {"with family": 0, "without family": 1},
    "Occupation": {"student": 0, "job holder": 1, "unemployed": 2},
    # "NA" = not applicable (respondent not in education): a genuine response category
    "EducationalYear": {"1st/2nd": 0, "3rd/4th/5th": 1, "graduate": 2, "NA": 3},
    "MaritalStatus": {"Married": 0, "Unmarried": 1},
    "SmokingHabit": {"no": 0, "yes": 1}, "Alcohol": {"no": 0, "yes": 1},
    "Place_of_Education": {"rural": 0, "urban": 1, "NA": 2},
    "UniversityType": {"public": 0, "private": 1, "NA": 2},
    "SleepTime": {"before 9": 0, "9 to 10": 1, "10 to 11": 2, "11 to 12": 3,
                  "12 to 1": 4, "after 1": 5},
    "AD1": {"Less than 1 week": 0, "1–2 weeks": 1, "2–4 weeks": 2, "More than 1 month": 3},
    "AD2": {"Stress": 1, "Emotional distress": 2, "Health issues": 3,
            "Environmental factors": 4, "Lifestyle habits": 5, "Other": 6},
    "AD3": {"Not at all": 0, "Slightly": 1, "Moderately": 2, "Severely": 3},
    "AD4": {"Rarely": 0, "Sometimes": 1, "Often": 2, "Almost always": 3},
    "AD5": {"Stay in bed and try to fall asleep": 1, "Get out of bed and do something relaxing": 2,
            "Use sleep aids": 3, "Watch TV or use electronic devices": 4, "Other": 5},
    "AD6": {"None of the above": 0, "Chronic insomnia": 1, "Anxiety disorder": 2,
            "Depression": 3, "Other sleep disorders": 4},
    "AD7": {"No": 0, "Yes, related to work or studies": 1, "Yes, related to relationships": 2,
            "Yes, related to health": 3, "Yes, other": 4},
    "AD13": {"Mild": 0, "Moderate": 1, "Severe": 2},
    "Insomnia": {"No_insomnia": 0, "Subthreshold_insomnia": 1, "moderate_Insomnia": 2,
                 "severe_Insomnia": 3},
    "Anxiety": {"No_Anxiety": 0, "Mild": 1, "Mild_moderate": 2, "Moderate_severe": 3,
                "Severe_very severe": 4},
}
for c in COMO:
    CODES[c] = {"no": 0, "yes": 1}
ORDINAL_VARS = (["Age", "SleepTime"] + ISI + HAMA +
                ["AD1", "AD3", "AD4", "AD8", "AD9", "AD10", "AD11", "AD12", "AD13"])
BINARY_VARS = ["LivingStatus", "MaritalStatus", "SmokingHabit", "Alcohol"] + COMO
ONEHOT_VARS = ["Gender", "Occupation", "EducationalYear", "Place_of_Education",
               "UniversityType", "AD2", "AD5", "AD6", "AD7"]
assert set(ORDINAL_VARS + BINARY_VARS + ONEHOT_VARS) == set(FEATURES)
CLASS_NAMES = {"insomnia": ["No insomnia", "Subthreshold", "Moderate", "Severe"],
               "anxiety": ["No anxiety", "Mild", "Mild–moderate", "Moderate–severe",
                           "Severe–very severe"]}


def load_data(verbose=True):
    raw = pd.read_excel(DATA_PATH, engine="openpyxl", keep_default_na=False, na_values=[""])
    raw.columns = [c.strip().replace("  ", " ") for c in raw.columns]
    raw = raw.rename(columns={"Place_of_ Education": "Place_of_Education",
                              "Doctor Opinion Insomnia": "Insomnia",
                              "Doctor Opinion Anxiety": "Anxiety"})
    n_raw = len(raw)
    df = pd.DataFrame(index=raw.index)
    for c in FEATURES + ["Insomnia", "Anxiety"]:
        if c in CODES:
            df[c] = raw[c].astype(str).str.strip().map(CODES[c])
        else:
            df[c] = pd.to_numeric(raw[c], errors="coerce")
    for c in ["ISI_Total", "HAM-Total"]:
        if c in raw.columns:
            df[c] = pd.to_numeric(raw[c], errors="coerce")
    df = df.dropna(subset=FEATURES + ["Insomnia", "Anxiety"])
    df = df[df["Insomnia"].isin([0, 1, 2, 3]) & df["Anxiety"].isin([0, 1, 2, 3, 4])]
    df[FEATURES + ["Insomnia", "Anxiety"]] = df[FEATURES + ["Insomnia", "Anxiety"]].astype(int)
    df = df.reset_index(drop=True)
    key = df[FEATURES + ["Insomnia", "Anxiety"]].astype(str).agg("|".join, axis=1)
    df["_profile_id"] = pd.factorize(key)[0]
    df["ISI_total"] = df[ISI].sum(1); df["HAMA_total"] = df[HAMA].sum(1)
    info = {"raw_rows": n_raw, "rows": len(df), "dropped": n_raw - len(df),
            "profiles": int(df["_profile_id"].nunique()),
            "redundant_rows": int(len(df) - df["_profile_id"].nunique()),
            "sha256": hashlib.sha256(open(DATA_PATH, "rb").read()).hexdigest()}
    if verbose:
        print(json.dumps(info))
    return df, info


def safe_strat(s):
    s = pd.Series(s).astype(str).reset_index(drop=True)
    vc = s.value_counts(); s = s.where(s.map(vc) >= 2, "rare")
    vc = s.value_counts()
    if vc.get("rare", 0) == 1:
        s = s.replace("rare", vc.drop("rare").idxmax())
    return s


def joint_codes(y_ins, y_anx):
    return pd.factorize(safe_strat(pd.Series(y_ins).astype(str) + "_" + pd.Series(y_anx).astype(str)))[0]


def grouped_split(n, codes, groups, test_size=TEST_SIZE, seed=SEED):
    sgkf = StratifiedGroupKFold(n_splits=int(round(1 / test_size)), shuffle=True, random_state=seed)
    tr, te = next(sgkf.split(np.zeros(n), codes, groups=groups))
    return tr, te


def get_split():
    df, info = load_data(verbose=False)
    codes = joint_codes(df["Insomnia"], df["Anxiety"])
    tr, te = grouped_split(len(df), codes, df["_profile_id"].values)
    assert not (set(df["_profile_id"].values[tr]) & set(df["_profile_id"].values[te]))
    return df, info, tr, te


def inner_folds(y_ins, y_anx, groups, n_splits=5, seed=SEED):
    cv = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(cv.split(np.zeros(len(y_ins)), joint_codes(y_ins, y_anx), groups=groups))

# ----------------------------------------------------------------------------- encoders/learners

def make_encoder(features):
    nums = [f for f in features if f in ORDINAL_VARS or f in BINARY_VARS]
    cats = [f for f in features if f in ONEHOT_VARS]
    tr = []
    if nums: tr.append(("num", "passthrough", nums))
    if cats: tr.append(("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cats))
    return ColumnTransformer(tr, remainder="drop")


SCALE = {"LR", "KNN", "GNB", "MLP"}


def make_learner(name, balanced=False, seed=SEED):
    cw = "balanced" if balanced else None
    if name == "LR": return LogisticRegression(max_iter=3000, C=1.0, class_weight=cw, random_state=seed)
    if name == "HGB": return HistGradientBoostingClassifier(learning_rate=0.1, max_leaf_nodes=31,
                                                            l2_regularization=1.0 if balanced else 0.0,
                                                            class_weight=cw, random_state=seed)
    if name == "RF": return RandomForestClassifier(n_estimators=300, class_weight=cw, random_state=seed, n_jobs=N_JOBS)
    if name == "ET": return ExtraTreesClassifier(n_estimators=300, class_weight=cw, random_state=seed, n_jobs=N_JOBS)
    if name == "GB": return GradientBoostingClassifier(random_state=seed)
    if name == "DT": return DecisionTreeClassifier(random_state=seed, class_weight=cw)
    if name == "GNB": return GaussianNB()
    if name == "KNN": return KNeighborsClassifier(n_neighbors=15, n_jobs=N_JOBS)
    if name == "MLP": return MLPClassifier(hidden_layer_sizes=(128, 64), max_iter=600,
                                           random_state=seed, early_stopping=True)
    raise ValueError(name)


def build_pipeline(name, features, balanced=False, seed=SEED):
    steps = [("enc", make_encoder(features))]
    if name in SCALE: steps.append(("sc", StandardScaler()))
    steps.append(("clf", make_learner(name, balanced, seed)))
    return Pipeline(steps)


def _proba_full(model, X, Kt):
    p = model.predict_proba(X); out = np.zeros((len(X), Kt))
    for j, c in enumerate(model.classes_): out[:, int(c)] = p[:, j]
    out = np.clip(out, 1e-9, None); return out / out.sum(1, keepdims=True)


class FrankHall:
    """Ordinal base learner: K-1 cumulative P(y>k) models, differenced into class probs."""
    def __init__(self, name, features, Kt, balanced=True, seed=SEED):
        self.name, self.features, self.Kt, self.balanced, self.seed = name, features, Kt, balanced, seed
    def fit(self, X, y):
        self.m_ = [build_pipeline(self.name, self.features, self.balanced, self.seed)
                   .fit(X[self.features], (y > k).astype(int)) for k in range(self.Kt - 1)]
        return self
    def proba(self, X):
        g = np.column_stack([m.predict_proba(X[self.features])[:, 1] for m in self.m_])
        g = np.clip(g, 1e-6, 1 - 1e-6)
        g = np.minimum.accumulate(g, axis=1)          # enforce monotone cumulative probabilities
        P = np.zeros((len(X), self.Kt)); P[:, 0] = 1 - g[:, 0]
        for k in range(1, self.Kt - 1): P[:, k] = g[:, k - 1] - g[:, k]
        P[:, -1] = g[:, -1]; P = np.clip(P, 1e-9, None)
        return P / P.sum(1, keepdims=True)


class Nominal:
    def __init__(self, name, features, Kt, balanced=True, seed=SEED):
        self.name, self.features, self.Kt, self.balanced, self.seed = name, features, Kt, balanced, seed
    def fit(self, X, y):
        self.m_ = build_pipeline(self.name, self.features, self.balanced, self.seed).fit(X[self.features], y)
        return self
    def proba(self, X):
        return _proba_full(self.m_, X[self.features], self.Kt)


def tune_offsets(proba, y, iters=60):
    """Coordinate ascent on per-class additive log-offsets, maximising macro-F1 (OOF only)."""
    logp = np.log(np.clip(proba, 1e-9, None)); b = np.zeros(proba.shape[1])
    score = lambda bb: f1_score(y, (logp + bb).argmax(1), average="macro")
    best = score(b); grid = np.array([-0.6, -0.3, -0.15, -0.05, 0.05, 0.15, 0.3, 0.6])
    for _ in range(iters):
        improved = False
        for k in range(len(b)):
            for d in grid:
                c = b.copy(); c[k] += d; s = score(c)
                if s > best + 1e-9: b, best, improved = c, s, True
        if not improved: break
    return b

# ----------------------------------------------------------------------------- OrdiFuse

class OrdiFuse:
    """Multitask cross-task ordinal stacking.

    bases     : list of (learner, kind) with kind in {"ord", "nom"}; all class-balanced.
    meta      : "HGB" | "LR"   meta-learner per task.
    fusion    : True -> meta input for task t = [OOF probs of t | OOF probs of other task].
    passthrough: True -> meta input also receives the (encoded) item responses.
    calibrate : isotonic calibration of the meta-learner.
    tune      : per-class decision offsets tuned on meta OOF predictions.
    """
    def __init__(self, features, bases=(("HGB", "ord"), ("ET", "ord"), ("LR", "ord")),
                 meta="HGB", fusion=True, passthrough=False, calibrate=False, tune=True,
                 n_folds=5, seed=SEED, tasks=TASKS, balanced=True):
        self.balanced = balanced   # revision: switch for the class-weighting ablation (default = published model)
        self.features = list(features); self.bases = list(bases); self.meta = meta
        self.fusion = fusion; self.passthrough = passthrough; self.calibrate = calibrate
        self.tune = tune; self.n_folds = n_folds; self.seed = seed; self.tasks = tasks

    def _base(self, name, kind, t):
        cls = FrankHall if kind == "ord" else Nominal
        return cls(name, self.features, K[t], balanced=getattr(self, "balanced", True), seed=self.seed)

    def _meta_est(self):
        if self.meta == "HGB":
            m = HistGradientBoostingClassifier(learning_rate=0.08, max_leaf_nodes=31, l2_regularization=1.0,
                                               class_weight="balanced" if getattr(self, "balanced", True) else None,
                                               random_state=self.seed)
        elif self.meta == "LR":
            m = Pipeline([("sc", StandardScaler()), ("clf", LogisticRegression(
                max_iter=3000, C=0.5, class_weight="balanced" if getattr(self, "balanced", True) else None,
                random_state=self.seed))])
        else:
            raise ValueError(self.meta)
        return CalibratedClassifierCV(m, method="isotonic", cv=3) if self.calibrate else m

    def _Z(self, P, t, Xenc):
        other = [o for o in self.tasks if o != t]
        parts = [np.hstack(P[t])]
        if self.fusion and other: parts.append(np.hstack(P[other[0]]))
        if self.passthrough: parts.append(Xenc)
        return np.hstack(parts)

    def fit(self, X, Y, groups):
        X = X.reset_index(drop=True); n = len(X)
        folds = inner_folds(Y[self.tasks[0]], Y[self.tasks[-1]], groups, self.n_folds, self.seed)
        oof = {t: [np.zeros((n, K[t])) for _ in self.bases] for t in self.tasks}
        for tr, va in folds:
            for t in self.tasks:
                for j, (nm, kd) in enumerate(self.bases):
                    oof[t][j][va] = self._base(nm, kd, t).fit(X.iloc[tr], Y[t][tr]).proba(X.iloc[va])
        self.base_ = {t: [self._base(nm, kd, t).fit(X, Y[t]) for nm, kd in self.bases] for t in self.tasks}
        if self.passthrough:
            self.enc_ = make_encoder(self.features).fit(X[self.features]); Xenc = self.enc_.transform(X[self.features])
        else:
            Xenc = None
        self.meta_, self.off_, self.meta_oof_ = {}, {}, {}
        for t in self.tasks:
            Z = self._Z(oof, t, Xenc); y = Y[t]
            mp = np.zeros((n, K[t]))
            for tr, va in folds:   # meta OOF on the same grouped folds (honest offsets)
                mp[va] = _proba_full(clone(self._meta_est()).fit(Z[tr], y[tr]), Z[va], K[t])
            self.meta_oof_[t] = mp
            self.meta_[t] = clone(self._meta_est()).fit(Z, y)
            self.off_[t] = tune_offsets(mp, y) if self.tune else np.zeros(K[t])
        return self

    def predict_proba(self, X, t):
        X = X.reset_index(drop=True)
        P = {u: [b.proba(X) for b in self.base_[u]] for u in self.tasks}
        Xenc = self.enc_.transform(X[self.features]) if self.passthrough else None
        return _proba_full(self.meta_[t], self._Z(P, t, Xenc), K[t])

    def predict_all(self, X):
        """Both tasks in one pass (base probabilities computed once). Returns (pred, proba)."""
        X = X.reset_index(drop=True)
        P = {u: [b.proba(X) for b in self.base_[u]] for u in self.tasks}
        Xenc = self.enc_.transform(X[self.features]) if self.passthrough else None
        proba = {t: _proba_full(self.meta_[t], self._Z(P, t, Xenc), K[t]) for t in self.tasks}
        pred = {t: (np.log(np.clip(proba[t], 1e-9, None)) + self.off_[t]).argmax(1) for t in self.tasks}
        return pred, proba

    def predict(self, X, t, proba=None):
        p = self.predict_proba(X, t) if proba is None else proba
        return (np.log(np.clip(p, 1e-9, None)) + self.off_[t]).argmax(1)

# ----------------------------------------------------------------------------- Stacking comparator

class OOFStack:
    """Single-task out-of-fold stack (the thesis 'Stacking comparator'): unweighted bases,
    isotonic-calibrated meta, grouped OOF folds."""
    def __init__(self, bases, meta, features, Kt, n_folds=5, seed=SEED):
        self.bases, self.meta, self.features, self.Kt = bases, meta, list(features), Kt
        self.n_folds, self.seed = n_folds, seed
    def _meta(self):
        m = (Pipeline([("sc", StandardScaler()), ("clf", LogisticRegression(max_iter=3000, random_state=self.seed))])
             if self.meta == "LR" else HistGradientBoostingClassifier(random_state=self.seed))
        return CalibratedClassifierCV(m, method="isotonic", cv=3)
    def fit(self, X, y, groups, folds=None):
        X = X.reset_index(drop=True); n = len(X)
        if folds is None:
            cv = StratifiedGroupKFold(self.n_folds, shuffle=True, random_state=self.seed)
            folds = list(cv.split(np.zeros(n), y, groups=groups))
        Z = []
        for nm in self.bases:
            P = np.zeros((n, self.Kt))
            for tr, va in folds:
                P[va] = _proba_full(build_pipeline(nm, self.features, False, self.seed)
                                    .fit(X.iloc[tr][self.features], y[tr]), X.iloc[va][self.features], self.Kt)
            Z.append(P)
        self.base_ = [build_pipeline(nm, self.features, False, self.seed).fit(X[self.features], y) for nm in self.bases]
        self.meta_ = self._meta().fit(np.hstack(Z), y)
        return self
    def predict_proba(self, X):
        Z = np.hstack([_proba_full(b, X[self.features], self.Kt) for b in self.base_])
        return _proba_full(self.meta_, Z, self.Kt)
    def predict(self, X):
        return self.predict_proba(X).argmax(1)

# ----------------------------------------------------------------------------- metrics

def macro_f1(y, p): return f1_score(y, p, average="macro")
def qwk(y, p): return cohen_kappa_score(y, p, weights="quadratic")
def mae(y, p): return mean_absolute_error(y, p)


def ece(y, proba, n_bins=15):
    conf = proba.max(1); acc = (proba.argmax(1) == np.asarray(y)).astype(float)
    bins = np.linspace(0, 1, n_bins + 1); e = 0.0
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.sum(): e += m.mean() * abs(acc[m].mean() - conf[m].mean())
    return e


def auc(y, proba):
    try: return roc_auc_score(y, proba, multi_class="ovr", average="macro")
    except Exception: return np.nan


def mt_f1(Y, P):
    return float(np.mean([macro_f1(Y[t], P[t]) for t in TASKS]))


def cached(name, fn):
    f = os.path.join(CACHE, name + ".joblib")
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r


