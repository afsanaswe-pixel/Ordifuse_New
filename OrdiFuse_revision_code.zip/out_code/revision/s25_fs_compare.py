"""R2.4 equal-budget (k = 24) comparison of item-selection strategies. Every ranking is computed on the TRAINING
partition only (the locked test set is used only to score the frozen subsets). Each subset is scored with
(i) OrdiFuse and (ii) class-balanced HGB (default), fitted on the training partition; paired profile-group
bootstrap differences against the model-aware subset S*."""
import json, time
from sklearn.feature_selection import mutual_info_classif, chi2, f_classif, RFE
from sklearn.linear_model import LogisticRegression
from sklearn.inspection import permutation_importance
from scipy.stats import spearmanr
from ofx import *
df, info, tr, te = get_split()
D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True); g = D["_profile_id"].values
Y = {"insomnia": D["Insomnia"].values, "anxiety": D["Anxiety"].values}; Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]; KS = len(S)
X = D[FEATURES].astype(float)
def mt_rank(scores):
    """scores: dict task -> pd.Series over FEATURES (higher = more relevant); multitask = mean of task-normalised scores."""
    s = sum((v.clip(lower=0) / v.clip(lower=0).sum()) for v in scores.values()) / len(scores)
    return list(s.sort_values(ascending=False).index)
def rk_mi():
    disc = [f not in ORDINAL_VARS for f in FEATURES]   # nominal & binary as discrete; ordinal treated as discrete too (integer-coded)
    return mt_rank({t: pd.Series(mutual_info_classif(X, Y[t], discrete_features=True, random_state=SEED), FEATURES) for t in TASKS})
def rk_chi2(): return mt_rank({t: pd.Series(chi2(X - X.min(), Y[t])[0], FEATURES) for t in TASKS})
def rk_anova(): return mt_rank({t: pd.Series(np.nan_to_num(f_classif(X, Y[t])[0]), FEATURES) for t in TASKS})
def rk_spear(): return mt_rank({t: pd.Series([abs(spearmanr(X[f], Y[t])[0]) if X[f].std() > 0 else 0 for f in FEATURES], FEATURES) for t in TASKS})
def rk_mrmr():
    """multitask mRMR (MID criterion; Peng et al., 2005) with discrete MI."""
    from sklearn.metrics import mutual_info_score
    rel = {f: np.mean([mutual_info_score(X[f], Y[t]) for t in TASKS]) for f in FEATURES}
    sel = [max(rel, key=rel.get)]; red = {f: 0.0 for f in FEATURES}
    while len(sel) < len(FEATURES):
        last = sel[-1]
        for f in FEATURES:
            if f not in sel: red[f] += mutual_info_score(X[f], X[last])
        cand = [f for f in FEATURES if f not in sel]
        sel.append(max(cand, key=lambda f: rel[f] - red[f] / len(sel)))
    return sel
def rk_l1():
    enc = make_encoder(FEATURES).fit(D[FEATURES]); Z = StandardScaler().fit_transform(enc.transform(D[FEATURES])); names = enc.get_feature_names_out()
    base = [n.split("__", 1)[1] for n in names]; base = [next(f for f in FEATURES if b == f or b.startswith(f + "_")) for b in base]
    sc = {}
    for t in TASKS:
        m = LogisticRegression(penalty="l1", solver="saga", C=0.05, max_iter=3000, class_weight="balanced", random_state=SEED).fit(Z, Y[t])
        sc[t] = pd.Series(np.abs(m.coef_).sum(0), index=base).groupby(level=0).sum().reindex(FEATURES).fillna(0)
    return mt_rank(sc)
def rk_rf():
    return mt_rank({t: pd.Series(RandomForestClassifier(500, class_weight="balanced", random_state=SEED, n_jobs=N_JOBS).fit(X, Y[t]).feature_importances_, FEATURES) for t in TASKS})
def rk_hgbperm():
    """model-aware but single-learner: permutation importance of class-balanced HGB on grouped held-out folds."""
    F = inner_folds(Y["insomnia"], Y["anxiety"], g, 5, SEED + 100); sc = {t: [] for t in TASKS}
    for a, b in F:
        for t in TASKS:
            m = HistGradientBoostingClassifier(class_weight="balanced", random_state=SEED).fit(X.iloc[a], Y[t][a])
            pi = permutation_importance(m, X.iloc[b], Y[t][b], scoring="f1_macro", n_repeats=3, random_state=SEED, n_jobs=1)
            sc[t].append(pd.Series(pi.importances_mean, FEATURES))
    return mt_rank({t: pd.concat(sc[t], axis=1).mean(1) for t in TASKS})
def rk_rfe():
    """wrapper: recursive feature elimination with a class-balanced random forest, joint over both tasks (sum of importances)."""
    cur = list(FEATURES)
    while len(cur) > KS:
        imp = sum(pd.Series(RandomForestClassifier(300, class_weight="balanced", random_state=SEED, n_jobs=N_JOBS).fit(X[cur], Y[t]).feature_importances_, cur) for t in TASKS)
        cur.remove(imp.idxmin())
    return cur
def rk_sfs():
    """wrapper: greedy sequential forward selection with class-balanced HGB (max_iter 60), grouped 3-fold CV multitask macro-F1."""
    F = inner_folds(Y["insomnia"], Y["anxiety"], g, 3, SEED + 300); cur = []
    while len(cur) < KS:
        best, bs = None, -1
        for f in FEATURES:
            if f in cur: continue
            fs = cur + [f]
            s = np.mean([macro_f1(Y[t][b], HistGradientBoostingClassifier(max_iter=60, class_weight="balanced", random_state=SEED)
                                  .fit(X.iloc[a][fs], Y[t][a]).predict(X.iloc[b][fs])) for a, b in F for t in TASKS])
            if s > bs: best, bs = f, s
        cur.append(best); print("SFS", len(cur), best, round(bs, 4), flush=True)
    return cur
METHODS = {"Model-aware OrdiFuse permutation (S*)": lambda: S,
           "Filter: mutual information": rk_mi, "Filter: chi-squared": rk_chi2, "Filter: ANOVA F": rk_anova,
           "Filter: |Spearman rho| (ordinal association)": rk_spear, "Filter: mRMR (MID)": rk_mrmr,
           "Embedded: L1-logistic": rk_l1, "Embedded: random-forest impurity": rk_rf,
           "Model-aware single learner: HGB permutation": rk_hgbperm,
           "Wrapper: RFE (random forest)": rk_rfe, "Wrapper: forward selection (HGB, 3-fold CV)": rk_sfs,
           "Instrument-based: full ISI + full HAM-A (21) + AD1, AD3, SleepTime": lambda: ISI + HAMA + ["AD1", "AD3", "SleepTime"]}
subsets = {}
for nm, fn in METHODS.items():
    t0 = time.time(); r = cached("fs_" + "".join(c for c in nm if c.isalnum())[:40], fn); subsets[nm] = list(r)[:KS]
    print(f"{nm}: {len(set(subsets[nm]) & set(S))}/24 overlap with S*  ({time.time()-t0:.0f}s) {subsets[nm]}", flush=True)
json.dump(subsets, open(os.path.join(OUT, "r24_subsets.json"), "w"), indent=1)
# random 24-item subsets (null distribution), scored with class-balanced HGB only
rng = np.random.default_rng(SEED); rnd = [[str(x) for x in rng.choice(FEATURES, KS, replace=False)] for _ in range(50)]
HYB5 = (("HGB", "ord"), ("ET", "ord"), ("LR", "ord"), ("HGB", "nom"), ("ET", "nom"))
P = {}
for nm, fs in subsets.items():
    P[("HGB", nm)] = cached("fsev_hgb_" + "".join(c for c in nm if c.isalnum())[:40], lambda fs=fs: {t: Nominal("HGB", fs, K[t], True).fit(D, Y[t]).proba(T).argmax(1) for t in TASKS})
    if nm.startswith("Model-aware OrdiFuse"):
        P[("OrdiFuse", nm)] = joblib.load(os.path.join(CACHE, "of24_main_test.joblib"))[0]
    else:
        P[("OrdiFuse", nm)] = cached("fsev_of_" + "".join(c for c in nm if c.isalnum())[:40], lambda fs=fs: OrdiFuse(fs, bases=HYB5, meta="HGB", passthrough=True).fit(D, Y, g).predict_all(T)[0])
    print(nm, {k[0]: round(mt_f1(Yt, v), 4) for k, v in P.items() if k[1] == nm}, flush=True)
R = cached("fs_random50_hgb", lambda: [mt_f1(Yt, {t: Nominal("HGB", fs, K[t], True).fit(D, Y[t]).proba(T).argmax(1) for t in TASKS}) for fs in rnd])
joblib.dump({"P": P, "random_hgb": R, "random_sets": rnd}, os.path.join(CACHE, "r24_fs_preds.joblib"))
print("random HGB: mean", np.mean(R), "max", np.max(R)); print("DONE")
