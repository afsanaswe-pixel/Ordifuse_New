"""R1.7 neural multitask baselines on S* with the same development budget as the tuned comparators:
random-search over a predefined grid by grouped 3-fold CV (early stopping on the held-out fold), out-of-fold
decision offsets on the 5 shared grouped folds (fixed epoch count), refit on the whole training partition,
one read of the locked test set. A single-task twin (same architecture/config, one head) controls for multitask sharing."""
import json, time, itertools, sys
from nnmt import *
df, info, tr, te = get_split()
D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True); g = D["_profile_id"].values
Y = {"insomnia": D["Insomnia"].values, "anxiety": D["Anxiety"].values}; Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
F5 = inner_folds(Y["insomnia"], Y["anxiety"], g, 5, SEED + 100); F3 = inner_folds(Y["insomnia"], Y["anxiety"], g, 3, SEED + 300)
MLPGRID = [dict(hidden=h, drop=dr, lr=lr, wd=wd) for h in [(128, 64), (256, 128), (512, 256, 128)] for dr in [0.0, 0.2] for lr in [1e-3, 3e-3] for wd in [1e-5, 1e-3]]
FTTGRID = [dict(d=d, n_blocks=nb, drop=dr, lr=lr, wd=1e-4) for d in [32, 64] for nb in [2, 3] for dr in [0.0, 0.1] for lr in [1e-3, 3e-4]]
FAMS = {"MT-MLP-CUM": dict(arch="mlp", kind="cum", grid=MLPGRID, n=10), "MT-MLP-CORAL": dict(arch="mlp", kind="coral", grid=MLPGRID, n=10),
        "MT-MLP-SOFT": dict(arch="mlp", kind="soft", grid=MLPGRID, n=10), "MT-FTT-CUM": dict(arch="ftt", kind="cum", grid=FTTGRID, n=2)}
only = sys.argv[1:] or list(FAMS)
def run_family(name, spec):
    grid = [spec["grid"][i] for i in np.random.default_rng(SEED + len(name)).choice(len(spec["grid"]), spec["n"], replace=False)]
    ep_max = 150 if spec["arch"] == "mlp" else 80; pat = 20 if spec["arch"] == "mlp" else 10
    res = []
    for cfg in grid:
        sc, eps = [], []
        for a, b in F3:
            m = NeuralMT(S, arch=spec["arch"], kind=spec["kind"], epochs=ep_max, patience=pat, **cfg).fit(
                D.iloc[a], {t: Y[t][a] for t in TASKS}, g[a], D.iloc[b], {t: Y[t][b] for t in TASKS})
            sc.append(m.best_val_); eps.append(m.best_epoch_)
        res.append((cfg, float(np.mean(sc)), int(round(np.mean(eps))))); print(name, cfg, round(res[-1][1], 4), res[-1][2], flush=True)
    cfg, cvs, ep = max(res, key=lambda r: r[1])
    return {"cfg": cfg, "inner_cv": cvs, "epochs": max(ep, 5), "search": res}
out = {}
for name in only:
    spec = FAMS[name]; t0 = time.time()
    tun = cached(f"nn_tune_{name}", lambda: run_family(name, spec))
    def oof_and_test(tasks_sets):
        P = {t: np.zeros((len(D), K[t])) for t in TASKS}; Pt = {}
        for ts in tasks_sets:
            for a, b in F5:
                m = NeuralMT(S, arch=spec["arch"], kind=spec["kind"], tasks=ts, fixed_epochs=tun["epochs"], **tun["cfg"]).fit(D.iloc[a], {t: Y[t][a] for t in ts}, g[a])
                pb = m.proba(D.iloc[b])
                for t in ts: P[t][b] = pb[t]
            t1 = time.time(); m = NeuralMT(S, arch=spec["arch"], kind=spec["kind"], tasks=ts, fixed_epochs=tun["epochs"], **tun["cfg"]).fit(D, {t: Y[t] for t in ts}, g)
            fit_s = time.time() - t1; t1 = time.time(); pt = m.proba(T); inf_s = time.time() - t1
            n_par = int(sum(np.size(x) for x in jax.tree_util.tree_leaves(m.p_)))
            for t in ts: Pt[t] = pt[t]
        off = {t: tune_offsets(P[t], Y[t]) for t in TASKS}
        pred = {t: (np.log(Pt[t]) + off[t]).argmax(1) for t in TASKS}
        cvf = {t: [macro_f1(Y[t][b], (np.log(P[t][b]) + off[t]).argmax(1)) for a, b in F5] for t in TASKS}
        return {"pred": pred, "proba": Pt, "oof": P, "cv_fold_mt": [np.mean([cvf[t][k] for t in TASKS]) for k in range(5)],
                "fit_s": fit_s, "inf_s": inf_s, "n_params": n_par}
    out[name] = cached(f"nn_eval_{name}", lambda: oof_and_test([TASKS]))
    r = out[name]; print(f"{name}: cfg {tun['cfg']} ep {tun['epochs']} | CV mt {np.mean(r['cv_fold_mt']):.4f} | TEST ins {macro_f1(Yt['insomnia'], r['pred']['insomnia']):.4f} anx {macro_f1(Yt['anxiety'], r['pred']['anxiety']):.4f} mt {mt_f1(Yt, r['pred']):.4f} ({time.time()-t0:.0f}s)", flush=True)
    if spec["arch"] == "mlp" and name == "MT-MLP-CUM":
        st = cached(f"nn_eval_ST_{name}", lambda: oof_and_test([("insomnia",), ("anxiety",)]))
        print(f"ST twin of {name}: CV mt {np.mean(st['cv_fold_mt']):.4f} | TEST mt {mt_f1(Yt, st['pred']):.4f} ins {macro_f1(Yt['insomnia'], st['pred']['insomnia']):.4f} anx {macro_f1(Yt['anxiety'], st['pred']['anxiety']):.4f}", flush=True)
print("DONE")
