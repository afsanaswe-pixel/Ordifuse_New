"""R1.5 nested architecture selection. For each of the three new profile-grouped 80/20 splits (seeds 101-103, as in
the repeated re-derivation), the six pre-specified variants V0-V5 are compared by grouped 3-fold CV on the outer
TRAINING part only (the 24 items of S*, which equal the re-derived subset in splits 1 and 3 and are contained in it in split 2; internal stacking folds = 3, as in the re-derivation); the winner is refitted on the
outer training part and scored once on the outer test part. The outer score therefore includes the architecture choice."""
import json, sys, time
from ofx import *
df, info = load_data(verbose=False)
codes = joint_codes(df["Insomnia"], df["Anxiety"]); G = df["_profile_id"].values
ORD3 = (("HGB", "ord"), ("ET", "ord"), ("LR", "ord")); HYB5 = ORD3 + (("HGB", "nom"), ("ET", "nom"))
VARIANTS = {"V0": dict(bases=ORD3, meta="HGB", calibrate=True), "V1": dict(bases=ORD3, meta="HGB"), "V2": dict(bases=HYB5, meta="HGB"),
            "V3": dict(bases=ORD3, meta="HGB", passthrough=True), "V4": dict(bases=HYB5, meta="HGB", passthrough=True), "V5": dict(bases=HYB5, meta="LR")}
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
REPS = [int(x) for x in sys.argv[1:]] or [0, 1, 2]
for rep in REPS:
    seed = [101, 102, 103][rep]
    tr, te = grouped_split(len(df), codes, G, 0.20, seed)
    D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True); g = D["_profile_id"].values
    Y = {"insomnia": D["Insomnia"].values, "anxiety": D["Anxiety"].values}; Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
    F = inner_folds(Y["insomnia"], Y["anxiety"], g, 3, seed + 1)
    inner = {}
    for vn, kw in VARIANTS.items():
        sc = []
        for k, (a, b) in enumerate(F):
            if vn == "V4":   # identical to the 51-item ladder fits of the re-derivation; recomputed here
                pass
            p = cached(f"nest{rep}_{vn}_f{k}", lambda a=a, b=b, kw=kw: OrdiFuse(S, **{**kw, "n_folds": 3}).fit(D.iloc[a], {t: Y[t][a] for t in TASKS}, g[a]).predict_all(D.iloc[b])[0])
            sc.append(np.mean([macro_f1(Y[t][b], p[t]) for t in TASKS]))
        inner[vn] = sc; print(f"rep{rep+1} {vn}: inner CV {np.mean(sc):.4f} ± {np.std(sc, ddof=1):.4f}", flush=True)
    win = max(inner, key=lambda v: np.mean(inner[v]))
    res = {"rep": rep + 1, "seed": seed, "inner": inner, "selected": win}
    for lab, feats in [("S*", S)]:
        p = cached(f"nest{rep}_final_{win}_{lab}", lambda feats=feats: OrdiFuse(feats, **VARIANTS[win]).fit(D, Y, g).predict_all(T)[0])
        res[f"outer_{lab}"] = {t: macro_f1(Yt[t], p[t]) for t in TASKS}; res[f"outer_{lab}"]["mt"] = mt_f1(Yt, p)
    json.dump(res, open(os.path.join(OUT, f"r15_nested_rep{rep+1}.json"), "w"), indent=1, default=float)
    print(json.dumps(res, default=float), flush=True)
print("DONE")
