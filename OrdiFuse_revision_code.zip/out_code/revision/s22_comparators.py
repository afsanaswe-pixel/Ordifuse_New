"""Re-generate locked-test predictions of the pre-declared comparators (identical code paths to s4_final/s10_tuned)
so that joint (both-task) metrics can be computed. Every model is fitted on the training partition only."""
import json, time
import lightgbm as lgb
from sklearn.utils.class_weight import compute_sample_weight
from ofx import *
df, info, tr, te = get_split()
D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True); g = D["_profile_id"].values
Y = {t: D[c].values for t, c in [("insomnia", "Insomnia"), ("anxiety", "Anxiety")]}
Yt = {t: T[c].values for t, c in [("insomnia", "Insomnia"), ("anxiety", "Anxiety")]}
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
ORD3 = (("HGB", "ord"), ("ET", "ord"), ("LR", "ord")); HYB5 = ORD3 + (("HGB", "nom"), ("ET", "nom"))
KW = dict(bases=HYB5, meta="HGB", passthrough=True)
SINGLES = ["LR", "HGB", "RF", "ET"]
GRID = [(["LR", "HGB"], "LR"), (["LR", "HGB"], "HGB"), (["LR", "HGB", "RF"], "LR"), (["LR", "HGB", "RF"], "HGB"),
        (["LR", "HGB", "ET"], "LR"), (["LR", "HGB", "ET"], "HGB"), (["HGB", "ET"], "LR"), (["HGB", "ET"], "HGB")]
def pick_stack(feats, tag):
    def run():
        a, b = grouped_split(len(D), joint_codes(Y["insomnia"], Y["anxiety"]), g, 0.20, SEED + 1)
        rows = []
        for bases, meta in GRID:
            s = np.mean([macro_f1(Y[t][b], OOFStack(bases, meta, feats, K[t]).fit(D.iloc[a], Y[t][a], g[a]).predict(D.iloc[b])) for t in TASKS])
            rows.append(("+".join(bases) + " -> " + meta, bases, meta, s)); print(rows[-1], flush=True)
        return sorted(rows, key=lambda r: -r[3])
    r = cached(f"stackgrid_{tag}", run)[0]; return r[1], r[2], r[0]
def stack_pred(bases, meta, feats):
    pr = {t: OOFStack(bases, meta, feats, K[t]).fit(D, Y[t], g).predict_proba(T) for t in TASKS}
    return {t: pr[t].argmax(1) for t in TASKS}, pr
def single(name, feats, bal):
    pr = {t: Nominal(name, feats, K[t], bal).fit(D, Y[t]).proba(T) for t in TASKS}
    return {t: pr[t].argmax(1) for t in TASKS}, pr
# --- LightGBM tuned + offsets (s10_tuned procedure)
F5 = inner_folds(Y["insomnia"], Y["anxiety"], g, 5, SEED + 100); F3 = inner_folds(Y["insomnia"], Y["anxiety"], g, 3, SEED + 300)
def lgbm_tuned():
    grid = [dict(num_leaves=nl, learning_rate=lr, n_estimators=ne, min_child_samples=20, subsample=0.8, subsample_freq=1, colsample_bytree=0.8, balanced=b)
            for nl in [15, 31] for lr in [0.05, 0.1] for ne in [200, 400] for b in [False, True]]
    grid = [grid[i] for i in np.random.default_rng(SEED + 4).choice(len(grid), 12, replace=False)]
    enc = lambda: ColumnTransformer([("num", "passthrough", [f for f in S if f in ORDINAL_VARS or f in BINARY_VARS]),
                                     ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), [f for f in S if f in ONEHOT_VARS])])
    class M:
        def __init__(s, p, Kt): s.p, s.Kt = dict(p), Kt
        def fit(s, X, y):
            p = dict(s.p); bal = p.pop("balanced"); s.e = enc().fit(X[S])
            s.m = lgb.LGBMClassifier(random_state=SEED, n_jobs=N_JOBS, verbose=-1, class_weight="balanced" if bal else None, **p).fit(s.e.transform(X[S]), y); return s
        def proba(s, X):
            p = s.m.predict_proba(s.e.transform(X[S])); o = np.zeros((len(X), s.Kt))
            for j, c in enumerate(s.m.classes_): o[:, int(c)] = p[:, j]
            o = np.clip(o, 1e-9, None); return o / o.sum(1, keepdims=True)
    pred, prob = {}, {}
    for t in TASKS:
        best = max(grid, key=lambda p: np.mean([macro_f1(Y[t][b], M(p, K[t]).fit(D.iloc[a], Y[t][a]).proba(D.iloc[b]).argmax(1)) for a, b in F3]))
        P = np.zeros((len(D), K[t]))
        for a, b in F5: P[b] = M(best, K[t]).fit(D.iloc[a], Y[t][a]).proba(D.iloc[b])
        off = tune_offsets(P, Y[t]); pt = M(best, K[t]).fit(D, Y[t]).proba(T)
        prob[t] = pt; pred[t] = (np.log(pt) + off).argmax(1); print("LGBM", t, best, flush=True)
    return pred, prob
JOBS = {
 "OrdiFuse (24)": lambda: joblib.load(os.path.join(CACHE, "of24_main_test.joblib")),
 "OrdiFuse without cross-task fusion (24)": lambda: OrdiFuse(S, **{**KW, "fusion": False}).fit(D, Y, g).predict_all(T),
 "OrdiFuse previous configuration V0 (24)": lambda: OrdiFuse(S, bases=ORD3, meta="HGB", calibrate=True).fit(D, Y, g).predict_all(T),
 "Stacking comparator, grid-selected (24)": lambda: stack_pred(["LR", "HGB", "RF"], "HGB", S),   # grid choice reported in the paper (stack_grid_S.csv)
 "Stacking comparator, class-balanced + offsets (24)": lambda: OrdiFuse(S, bases=(("LR", "nom"), ("HGB", "nom"), ("RF", "nom")), meta="HGB", fusion=False, passthrough=False, tune=True).fit(D, Y, g).predict_all(T),
 "HGB class-balanced, default (24)": lambda: single("HGB", S, True),
 "LightGBM tuned + offsets (24)": lgbm_tuned,
 "OrdiFuse (51)": lambda: OrdiFuse(FEATURES, **KW).fit(D, Y, g).predict_all(T),
}
key = lambda nm: "".join(c if c.isalnum() else "_" for c in nm)[:60]
for nm, fn in JOBS.items():
    t0 = time.time(); p, pr = cached("cmp_" + key(nm), fn)
    print(f"{nm:<55s} ins {macro_f1(Yt['insomnia'], p['insomnia']):.4f} anx {macro_f1(Yt['anxiety'], p['anxiety']):.4f} mt {mt_f1(Yt, p):.4f} ({time.time()-t0:.0f}s)", flush=True)
print("DONE")
