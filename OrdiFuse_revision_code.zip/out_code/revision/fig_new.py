import pandas as pd, numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, os, json
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "font.family": "DejaVu Sans"})
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]; GR = "#8a8984"
O = "/home/claude/rev/figs"; W = "/home/claude/rev/work/out"
def letter(ax, s): ax.text(-0.02, 1.04, s, transform=ax.transAxes, fontsize=11, fontweight="bold", ha="right", va="bottom")
# ---------- Figure 12: incorporation probes
b = pd.read_csv(f"{W}/r11_block_predictability.csv")
fig, axs = plt.subplots(1, 2, figsize=(10, 3.4), gridspec_kw={"width_ratios": [1.15, 1]})
for ax, t, col, lab in [(axs[0], "insomnia", C[0], "a"), (axs[1], "anxiety", C[1], "b")]:
    d = b[b.task == t].iloc[::-1]
    y = np.arange(len(d)); ax.barh(y, d.macro_f1, color=col, height=0.6)
    for yi, v in zip(y, d.macro_f1): ax.text(v + 0.005, yi, f"{v:.3f}", va="center", fontsize=8)
    ax.set_yticks(y, d.predictors); ax.set_xlim(0.6, 1.04); ax.set_xlabel(f"Held-out macro-F1, {t} grade")
    ax.axvline(0.9899 if t == "insomnia" else 0.8820, color=GR, ls=":", lw=1); ax.text(0.9899 if t == "insomnia" else 0.8820, len(d) - 0.4, "OrdiFuse (24)", fontsize=7.5, color=GR, ha="right")
    letter(ax, lab)
plt.tight_layout(); plt.savefig(f"{O}/Figure12.png", dpi=300); plt.close()
# ---------- Figure 13: transport decomposition
d = pd.read_csv(f"{W}/r25_transport_decomposition.csv"); pool = pd.read_csv(f"{W}/r25_pooling_test.csv") if os.path.exists(f"{W}/r25_pooling_test.csv") else None
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
short = {"Non-students → students": "Non-students\n→ students", "Students → non-students": "Students\n→ non-students", "Urban → rural": "Urban\n→ rural", "Rural → urban": "Rural\n→ urban"}
for ax, t, lab in [(axs[0], "insomnia", "a"), (axs[1], "anxiety", "b")]:
    q = d[d.task == t].reset_index(drop=True); x = np.arange(len(q)); w = 0.16
    series = [("In-domain (target CV)", q.F1_target_inCV, C[0]), ("Transported", q.F1_transport, C[1]),
              ("+ covariate reweighting", q.F1_transport_cov_reweighted, C[2]), ("+ EM prior correction", q.F1_transport_EM_prior, C[3])]
    if pool is not None:
        pp = pool[pool.task == t].set_index("direction").reindex(q.direction)
        series.append(("Target + source pooled", pp.F1_B_target_plus_source.values, C[5]))
    k = len(series)
    for i, (nm, v, c) in enumerate(series):
        ax.bar(x + (i - (k - 1) / 2) * w, v, w * 0.9, color=c, label=nm)
    ax.set_xticks(x, [short[s] for s in q.direction]); ax.set_ylim(0.74 if t == "anxiety" else 0.88, 1.0 if t == "insomnia" else 0.88)
    ax.set_ylabel(f"Macro-F1, {t}"); letter(ax, lab)
h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, frameon=False, fontsize=8, loc="lower center", ncol=5)
fig.subplots_adjust(left=0.07, right=0.99, wspace=0.25, bottom=0.25, top=0.9); plt.savefig(f"{O}/Figure13.png", dpi=300); plt.close()
print("ok")
# ---------- Figure 15: equal-budget selection
R = pd.read_csv(f"{W}/r24_fs_table.csv")
rnd = None
try:
    import joblib; rnd = joblib.load("/home/claude/rev/work/cache/fs_random50_hgb.joblib")
except Exception: pass
short = {"Model-aware OrdiFuse permutation (S*)": "S* (model-aware, OrdiFuse)", "Model-aware single learner: HGB permutation": "Model-aware, HGB permutation",
         "Wrapper: forward selection (HGB, 3-fold CV)": "Wrapper: forward selection", "Wrapper: RFE (random forest)": "Wrapper: RFE",
         "Instrument-based: full ISI + full HAM-A (21) + AD1, AD3, SleepTime": "ISI + HAM-A + 3 items of S*",
         "Filter: |Spearman rho| (ordinal association)": "Filter: |Spearman ρ|", "Filter: chi-squared": "Filter: χ²"}
R["lab"] = [short.get(m, m) for m in R.method]; R = R.sort_values("OrdiFuse_mt")
fig, ax = plt.subplots(figsize=(7.5, 4.2)); y = np.arange(len(R))
ax.scatter(R.OrdiFuse_mt, y, s=40, color=C[0], label="Scored with OrdiFuse", zorder=3)
ax.scatter(R.HGB_mt, y, s=40, color=C[1], marker="D", label="Scored with class-balanced HGB", zorder=3)
for yi, (a, b) in enumerate(zip(R.OrdiFuse_mt, R.HGB_mt)): ax.plot([b, a], [yi, yi], color="#c9c8c3", lw=1, zorder=1)
if False:
    lo, hi = np.percentile(rnd, [2.5, 97.5]); ax.axvspan(lo, hi, color=C[1], alpha=0.10, lw=0)
    ax.text(hi, len(R) - 0.4, "50 random 24-item subsets (HGB), 95% range", fontsize=7, color="#52514e", ha="right")
ax.set_yticks(y, R.lab); ax.set_xlabel("Held-out multitask macro-F1 (24 items)")
i = list(R.method).index("Model-aware OrdiFuse permutation (S*)"); ax.get_yticklabels()[i].set_fontweight("bold")
ax.legend(frameon=False, fontsize=8, loc="upper left"); plt.tight_layout(); plt.savefig(f"{O}/Figure15.png", dpi=300); plt.close()
print("fig15")
# ---------- Figure 14: ablation forest plot
P = pd.read_csv(f"{W}/r23_ablation_pooled.csv")
lab = {"B − cross-task fusion": "− cross-task fusion", "C − item passthrough": "− item passthrough", "D − fusion − passthrough (plain ordinal+nominal stack)": "− fusion and passthrough",
       "E − nominal level-0 learners (ordinal only)": "− nominal level-0 learners", "F − ordinal level-0 learners (nominal only)": "− ordinal level-0 learners*",
       "G − class weighting": "− class weighting*", "H − decision offsets": "− decision offsets", "I LR meta-learner instead of HGB": "LR meta-learner*", "J isotonic calibration layer added": "+ isotonic layer*"}
P = P[P.variant.isin(lab)].iloc[::-1].reset_index(drop=True)
fig, ax = plt.subplots(figsize=(7, 3.8)); y = np.arange(len(P))
for i, r in P.iterrows():
    sig = r.lo > 0 or r.hi < 0; c = C[1] if sig else GR
    ax.plot([r.lo, r.hi], [i, i], color=c, lw=2); ax.scatter(r.pooled_delta, i, color=c, s=36, zorder=3)
ax.axvline(0, color="#52514e", lw=0.8); ax.set_yticks(y, [lab[v] for v in P.variant])
ax.set_xlabel("Loss in multitask macro-F1 when the component is removed or swapped\n(positive = component helps; pooled over held-out sets, 95% CI)")
ax.text(0.99, 1.01, "* locked test set only; others pooled over 4 held-out sets", transform=ax.transAxes, ha="right", va="bottom", fontsize=7, color="#52514e")
plt.tight_layout(); plt.savefig(f"{O}/Figure14.png", dpi=300); plt.close(); print("fig14")
# ---------- Figure 16: event-level validation
E = pd.read_csv(f"{W}/r18_event_validation.csv"); L = pd.read_csv(f"{W}/r18_loeo.csv")
fig, axs = plt.subplots(1, 2, figsize=(11, 3.9), gridspec_kw={"width_ratios": [0.8, 1.35]})
ax = axs[0]; order = ["Temporal: 2022–2023 → 2024–2025", "Temporal: 2024–2025 → 2022–2023"]
lab = ["2022–2023 → 2024–2025", "2024–2025 → 2022–2023"]
mods = [("HGB class-balanced (24), in-domain CV in target", "In-domain reference (HGB, CV in target)", "#c9c8c3"), ("OrdiFuse (24)", "OrdiFuse", C[0]),
        ("Stacking comparator (24)", "Stacking comparator", C[1]), ("HGB class-balanced (24)", "HGB, class-balanced", C[2]), ("Published cut-off rule", "Cut-off rule", C[3])]
x = np.arange(2); w = 0.16
for i, (m, nm, c) in enumerate(mods):
    v = [E[(E.split == s) & (E.model == m)].f1_mt.values[0] for s in order]
    ax.bar(x + (i - 2) * w, v, w * 0.9, color=c, label=nm)
ax.set_xticks(x, lab, fontsize=8); ax.set_ylim(0.5, 0.95); ax.set_ylabel("Multitask macro-F1 in the target"); letter(ax, "a")
ax.legend(frameon=False, fontsize=7, loc="upper center", ncol=2, bbox_to_anchor=(0.5, -0.2))
ax = axs[1]; hosp = [2, 4, 6, 7, 10, 11, 14, 15, 16, 22]
cols = [C[0] for e in L.event]
ax.bar(np.arange(len(L)), L.joint_exact, color=cols, width=0.75)
ax.set_xticks(np.arange(len(L)), L.event, rotation=90, fontsize=7.5); ax.set_ylabel("Both grades exactly right (%)"); ax.set_ylim(0, 105)
from matplotlib.patches import Patch

ax.axvline(14.5, color="#52514e", ls=":", lw=1); ax.text(14.6, 101, "2024–2025 →", fontsize=7.5, color="#52514e")
letter(ax, "b"); fig.subplots_adjust(left=0.06, right=0.99, bottom=0.3, top=0.92, wspace=0.18)
plt.savefig(f"{O}/Figure16.png", dpi=300); plt.close(); print("fig16")
