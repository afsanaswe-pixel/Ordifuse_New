"""R1.2 physician-level analyses: grade distribution by grading physician, OrdiFuse test performance by physician,
and a test of physician effect on P(grade | items) (does a physician indicator improve grouped-CV log-loss?)."""
import json
from scipy import stats
from ofx import *
df, info, tr, te = get_split()
X = pd.read_csv("/home/claude/rev/ev/extra.csv"); df["Phys"] = X["Physicians1_ID"].values; df["Event"] = X["Event_ID"].values
T = df.iloc[te].reset_index(drop=True); Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
p, _ = joblib.load(os.path.join(CACHE, "of24_main_test.joblib"))
rows = []
for ph in sorted(df.Phys.unique()):
    m = (T.Phys == ph).values; a = df.Phys == ph
    r = {"physician": ph, "n_all": int(a.sum()), "n_test": int(m.sum())}
    for t, c in [("insomnia", "Insomnia"), ("anxiety", "Anxiety")]:
        r.update({f"{t}_grade{k}_pct": round(100 * (df.loc[a, c] == k).mean(), 1) for k in range(K[t])})
        r[f"{t}_test_f1"] = macro_f1(Yt[t][m], p[t][m]); r[f"{t}_test_acc"] = 100 * np.mean(Yt[t][m] == p[t][m])
    r["joint_exact"] = 100 * np.mean((Yt["insomnia"][m] == p["insomnia"][m]) & (Yt["anxiety"][m] == p["anxiety"][m]))
    rows.append(r)
R = pd.DataFrame(rows); R.round(4).to_csv(os.path.join(OUT, "r12_by_physician.csv"), index=False); pd.set_option("display.width", 250); print(R.round(3).to_string())
for t, c in [("insomnia", "Insomnia"), ("anxiety", "Anxiety")]:
    ct = pd.crosstab(df.Phys, df[c]); print(t, "chi2 p (grade distribution by physician)", stats.chi2_contingency(ct)[1])
    acc = pd.crosstab(T.Phys, Yt[t] == p[t]); print(t, "chi2 p (test accuracy by physician)", stats.chi2_contingency(acc)[1])
# physician effect on grade given items: grouped 5-fold CV log-loss with vs without physician one-hot
g = df["_profile_id"].values; base = FEATURES; PH = pd.get_dummies(df.Phys).values.astype(float)
res = []
for t, c in [("insomnia", "Insomnia"), ("anxiety", "Anxiety")]:
    y = df[c].values; L = {}
    for lab, add in [("items", False), ("items+physician", True)]:
        P = np.zeros((len(df), K[t]))
        for a, b in inner_folds(df["Insomnia"].values, df["Anxiety"].values, g, 5, SEED):
            enc = make_encoder(base).fit(df.iloc[a][base]); Xa = enc.transform(df.iloc[a][base]); Xb = enc.transform(df.iloc[b][base])
            if add: Xa, Xb = np.c_[Xa, PH[a]], np.c_[Xb, PH[b]]
            P[b] = np.clip(HistGradientBoostingClassifier(random_state=SEED).fit(Xa, y[a]).predict_proba(Xb), 1e-9, None)
        L[lab] = P
    l0 = -np.log(L["items"][np.arange(len(y)), y]); l1 = -np.log(L["items+physician"][np.arange(len(y)), y]); dlt = l0 - l1
    z = dlt.mean() / (dlt.std(ddof=1) / np.sqrt(len(dlt)))
    res.append({"task": t, "logloss_items": l0.mean(), "logloss_items_plus_physician": l1.mean(), "improvement": dlt.mean(), "z": z, "p_one_sided": stats.norm.sf(z),
                "f1_items": macro_f1(y, L["items"].argmax(1)), "f1_items_plus_physician": macro_f1(y, L["items+physician"].argmax(1))})
    print(res[-1], flush=True)
pd.DataFrame(res).round(5).to_csv(os.path.join(OUT, "r12_physician_effect.csv"), index=False)
