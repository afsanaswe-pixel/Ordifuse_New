"""R1.8 temporal / venue / leave-one-event-out validation using the record-level Event_ID added in revision.
OrdiFuse and comparators use the 24 items of S* (derived on the main training partition, which contains events
from every period: a mild item-selection advantage that applies to all models equally). Reporting only."""
import json, sys, time
from ofx import *
df, info = load_data(verbose=False)
X = pd.read_csv("/home/claude/rev/ev/extra.csv"); df["Event"] = X["Event_ID"].values
df["EvN"] = df.Event.str[1:].astype(int)
VEN = {e: ("Hospital" if e in [2, 4, 6, 7, 10, 11, 14, 15, 16, 22] else "University") for e in range(1, 24)}
df["Venue"] = df.EvN.map(VEN)
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
HYB5 = (("HGB", "ord"), ("ET", "ord"), ("LR", "ord"), ("HGB", "nom"), ("ET", "nom"))
TN = {"insomnia": "Insomnia", "anxiety": "Anxiety"}
SPLITS = {"Temporal: 2022–2023 → 2024–2025": (df.EvN <= 15, df.EvN >= 16),
          "Temporal: 2024–2025 → 2022–2023": (df.EvN >= 16, df.EvN <= 15),
          "Venue: university → hospital": (df.Venue == "University", df.Venue == "Hospital"),
          "Venue: hospital → university": (df.Venue == "Hospital", df.Venue == "University")}
which = sys.argv[1:] or list(SPLITS)
rows = []
for nm in which:
    a, b = SPLITS[nm]; D = df[a.values].reset_index(drop=True); T = df[b.values].reset_index(drop=True); g = D["_profile_id"].values
    Y = {t: D[c].values for t, c in TN.items()}; Yt = {t: T[c].values for t, c in TN.items()}
    k = "".join(ch for ch in nm if ch.isalnum())[:40]
    t0 = time.time()
    P = {"OrdiFuse (24)": cached(f"ev_of_{k}", lambda: OrdiFuse(S, bases=HYB5, meta="HGB", passthrough=True).fit(D, Y, g).predict_all(T)[0]),
         "Stacking comparator (24)": cached(f"ev_st_{k}", lambda: {t: OOFStack(["LR", "HGB", "RF"], "HGB", S, K[t]).fit(D, Y[t], g).predict(T) for t in TASKS}),
         "HGB class-balanced (24)": cached(f"ev_hgb_{k}", lambda: {t: Nominal("HGB", S, K[t], True).fit(D, Y[t]).proba(T).argmax(1) for t in TASKS}),
         "Published cut-off rule": {"insomnia": np.digitize(T["ISI_total"], [7, 14, 21], right=True), "anxiety": np.digitize(T["HAMA_total"], [13, 17, 24, 30], right=True)}}
    # in-domain reference: grouped 5-fold CV within the target with OrdiFuse is costly; use class-balanced HGB (24) for both
    def indom():
        out = {t: np.zeros(len(T), int) for t in TASKS}
        for aa, bb in inner_folds(Yt["insomnia"], Yt["anxiety"], T["_profile_id"].values, 5, SEED):
            for t in TASKS: out[t][bb] = Nominal("HGB", S, K[t], True).fit(T.iloc[aa], Yt[t][aa]).proba(T.iloc[bb]).argmax(1)
        return out
    P["HGB class-balanced (24), in-domain CV in target"] = cached(f"ev_in_{k}", indom)
    for m, p in P.items():
        rows.append({"split": nm, "n_dev": len(D), "n_target": len(T), "model": m, "f1_ins": macro_f1(Yt["insomnia"], p["insomnia"]), "f1_anx": macro_f1(Yt["anxiety"], p["anxiety"]),
                     "f1_mt": mt_f1(Yt, p), "qwk": np.mean([qwk(Yt[t], p[t]) for t in TASKS]),
                     "joint_exact": 100 * np.mean((p["insomnia"] == Yt["insomnia"]) & (p["anxiety"] == Yt["anxiety"]))})
        print(nm, "|", m, round(rows[-1]["f1_ins"], 4), round(rows[-1]["f1_anx"], 4), round(rows[-1]["f1_mt"], 4), f"({time.time()-t0:.0f}s)", flush=True)
f = os.path.join(OUT, "r18_event_validation.csv")
old = pd.read_csv(f) if os.path.exists(f) else pd.DataFrame()
pd.concat([old[~old.split.isin(which)] if len(old) else old, pd.DataFrame(rows)]).round(4).to_csv(f, index=False)
