"""R2.5 data-pooling test of conditional (grade-given-items) shift. For each direction, the TARGET sub-cohort is split
into 5 grouped folds; on each held-out target fold we compare a class-balanced HGB trained on
 (A) the other target folds only,
 (B) the other target folds + the whole source sub-cohort,
 (C) as B with a source/target indicator as an extra input (lets the model learn a cohort-specific mapping).
If P(grade | items) were the same in both sub-cohorts, adding source data (B) should not hurt A. B < A, and C > B,
indicate that the item-to-grade mapping differs between the sub-cohorts (conditional shift)."""
from ofx import *
from sklearn.utils.class_weight import compute_sample_weight
df, info = load_data(verbose=False)
TN = {"insomnia": "Insomnia", "anxiety": "Anxiety"}
occ = df["Occupation"] == 0; urb = df["Place_of_Education"] == 1; rur = df["Place_of_Education"] == 0
DIRS = [("Non-students → students", ~occ, occ), ("Students → non-students", occ, ~occ), ("Urban → rural", urb, rur), ("Rural → urban", rur, urb)]
rng = np.random.default_rng(SEED); rows = []
for name, sm, tm in DIRS:
    Src = df[sm.values].reset_index(drop=True); V = df[tm.values].reset_index(drop=True)
    enc = make_encoder(FEATURES).fit(pd.concat([Src, V])[FEATURES])
    Xs, Xv = enc.transform(Src[FEATURES]), enc.transform(V[FEATURES])
    F = inner_folds(V["Insomnia"].values, V["Anxiety"].values, V["_profile_id"].values, 5, SEED)
    for t in TASKS:
        ys, yv = Src[TN[t]].values, V[TN[t]].values; pred = {k: np.zeros(len(V), int) for k in "ABC"}
        for a, b in F:
            def fit(X, y): return HistGradientBoostingClassifier(learning_rate=0.1, max_leaf_nodes=31, l2_regularization=1.0, class_weight="balanced", random_state=SEED).fit(X, y)
            pred["A"][b] = fit(Xv[a], yv[a]).predict(Xv[b])
            pred["B"][b] = fit(np.r_[Xv[a], Xs], np.r_[yv[a], ys]).predict(Xv[b])
            XA = np.c_[np.r_[Xv[a], Xs], np.r_[np.ones(len(a)), np.zeros(len(Xs))]]
            pred["C"][b] = fit(XA, np.r_[yv[a], ys]).predict(np.c_[Xv[b], np.ones(len(b))])
        f = {k: macro_f1(yv, pred[k]) for k in "ABC"}
        bs = {"B-A": [], "C-B": []}
        for _ in range(1000):
            i = rng.integers(0, len(yv), len(yv)); fa, fb, fc = (macro_f1(yv[i], pred[k][i]) for k in "ABC")
            bs["B-A"].append(fb - fa); bs["C-B"].append(fc - fb)
        rows.append({"direction": name, "task": t, "n_target": len(V), "n_source_added": len(Src),
                     "F1_A_target_only": f["A"], "F1_B_target_plus_source": f["B"], "F1_C_plus_indicator": f["C"],
                     "B_minus_A": f["B"] - f["A"], "B_minus_A_lo": np.percentile(bs["B-A"], 2.5), "B_minus_A_hi": np.percentile(bs["B-A"], 97.5),
                     "C_minus_B": f["C"] - f["B"], "C_minus_B_lo": np.percentile(bs["C-B"], 2.5), "C_minus_B_hi": np.percentile(bs["C-B"], 97.5)})
        print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in rows[-1].items()}, flush=True)
pd.DataFrame(rows).round(4).to_csv(os.path.join(OUT, "r25_pooling_test.csv"), index=False); print("DONE")
