"""R1.1 incorporation-bias probes (reporting only). Train on the training partition, score on the locked test set."""
import json
from sklearn.tree import DecisionTreeClassifier
from ofx import *
df, info, tr, te = get_split()
D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True)
TN = {"insomnia": "Insomnia", "anxiety": "Anxiety"}
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
res = {}
# 1. grade discordance among respondents with an identical OWN-instrument item vector (whole cohort)
def discord(frame, cols, t):
    k = frame[cols].astype(str).agg("|".join, axis=1); y = frame[TN[t]]
    g = frame.assign(_k=k).groupby("_k")[TN[t]]
    size = g.transform("size"); nun = g.transform("nunique")
    maj = g.apply(lambda s: s.value_counts().iloc[0]).sum()
    return {"vectors": int(k.nunique()), "rows_in_shared_vectors": int((size > 1).sum()),
            "rows_in_discordant_vectors": int((nun > 1).sum()),
            "pct_rows_discordant_among_shared": round(100 * (nun > 1).sum() / max((size > 1).sum(), 1), 2),
            "in_sample_ceiling_acc_pct": round(100 * maj / len(frame), 2)}
rows = []
for t, nm, cols in [("insomnia", "ISI1-7", ISI), ("insomnia", "ISI1-7 + HAM4", ISI + ["HAM4"]),
                    ("insomnia", "ISI1-4 (retained)", ISI[:4]),
                    ("anxiety", "HAM1-14", HAMA), ("anxiety", "HAM1-14 + ISI1-7", HAMA + ISI),
                    ("insomnia", "all 51 items", FEATURES), ("anxiety", "all 51 items", FEATURES)]:
    rows.append({"task": t, "vector": nm, **discord(df, cols, t)})
pd.DataFrame(rows).to_csv(os.path.join(OUT, "r11_discordance.csv"), index=False); print(pd.DataFrame(rows).to_string())
# 2. held-out predictability of each grade from restricted item blocks (class-balanced HGB, defaults)
blocks = {
 "insomnia": [("ISI items only (7)", ISI), ("ISI total only", ["ISI_total"]), ("ISI items + HAM4 (8)", ISI + ["HAM4"]),
              ("All items except ISI (44)", [f for f in FEATURES if f not in ISI]),
              ("All items except ISI and HAM4 (43)", [f for f in FEATURES if f not in ISI + ["HAM4"]]),
              ("Sociodemographic + comorbidity only (17)", SOCIO + COMO), ("All 51 items", FEATURES)],
 "anxiety": [("HAM-A items only (14)", HAMA), ("HAM-A total only", ["HAMA_total"]), ("HAM-A + ISI items (21)", HAMA + ISI),
             ("All items except HAM-A (37)", [f for f in FEATURES if f not in HAMA]),
             ("Sociodemographic + comorbidity only (17)", SOCIO + COMO), ("All 51 items", FEATURES)]}
pr = []
for t, bl in blocks.items():
    for nm, cols in bl:
        Xa, Xb = D[cols], T[cols]
        if cols[0] in ("ISI_total", "HAMA_total"):
            m = HistGradientBoostingClassifier(class_weight="balanced", random_state=SEED).fit(Xa, D[TN[t]])
            p = m.predict(Xb)
        else:
            p = Nominal("HGB", cols, K[t], True).fit(D, D[TN[t]].values).proba(T).argmax(1)
        yt = T[TN[t]].values
        pr.append({"task": t, "predictors": nm, "n_items": len(cols), "macro_f1": round(macro_f1(yt, p), 4),
                   "exact_pct": round(100 * np.mean(yt == p), 2), "qwk": round(qwk(yt, p), 4)})
        print(pr[-1], flush=True)
pd.DataFrame(pr).to_csv(os.path.join(OUT, "r11_block_predictability.csv"), index=False)
# 3. depth needed by a single tree on the ISI items to reproduce the insomnia grade
dt = []
for d in [2, 3, 4, 6, 8, 10, 12, None]:
    m = DecisionTreeClassifier(max_depth=d, random_state=SEED).fit(D[ISI], D["Insomnia"])
    dt.append({"max_depth": d if d else "unrestricted", "leaves": int(m.get_n_leaves()),
               "test_macro_f1": round(macro_f1(T["Insomnia"], m.predict(T[ISI])), 4)})
pd.DataFrame(dt).to_csv(os.path.join(OUT, "r11_isi_tree_depth.csv"), index=False); print(pd.DataFrame(dt))
# 4. monotonicity of the grade in the ISI total: share of respondents whose grade is lower than that of someone with a lower total
