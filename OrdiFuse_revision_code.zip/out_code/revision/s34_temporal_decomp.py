"""R1.8 / R2.5 decomposition of the temporal (and venue) performance drop with class-balanced HGB on the 24 items:
grade prevalence by period, transported vs in-domain performance, prior (label-shift) correction, and the
data-pooling test (target folds only vs target folds + whole source vs + source indicator)."""
import json
from ofx import *
df, info = load_data(verbose=False)
X = pd.read_csv("/home/claude/rev/ev/extra.csv"); df["EvN"] = X["Event_ID"].str[1:].astype(int).values
df["Venue"] = np.where(df.EvN.isin([2, 4, 6, 7, 10, 11, 14, 15, 16, 22]), "Hospital", "University")
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]; TN = {"insomnia": "Insomnia", "anxiety": "Anxiety"}
DIRS = [("2022–2023 → 2024–2025", df.EvN <= 15, df.EvN >= 16), ("2024–2025 → 2022–2023", df.EvN >= 16, df.EvN <= 15),
        ("University → hospital", df.Venue == "University", df.Venue == "Hospital"), ("Hospital → university", df.Venue == "Hospital", df.Venue == "University")]
rng = np.random.default_rng(SEED); rows = []; prev = []
def hgb(): return HistGradientBoostingClassifier(learning_rate=0.1, max_leaf_nodes=31, l2_regularization=1.0, class_weight="balanced", random_state=SEED)
for nm, sm, tm in DIRS:
    Src = df[sm.values].reset_index(drop=True); V = df[tm.values].reset_index(drop=True)
    enc = make_encoder(S).fit(pd.concat([Src, V])[S]); Xs, Xv = enc.transform(Src[S]), enc.transform(V[S])
    F = inner_folds(V["Insomnia"].values, V["Anxiety"].values, V["_profile_id"].values, 5, SEED)
    for t in TASKS:
        ys, yv = Src[TN[t]].values, V[TN[t]].values; P = {k: np.zeros(len(V), int) for k in ["X", "A", "B", "C"]}
        m = hgb().fit(Xs, ys); pr = m.predict_proba(Xv); P["X"] = m.classes_[pr.argmax(1)]
        for a, b in F:
            P["A"][b] = hgb().fit(Xv[a], yv[a]).predict(Xv[b])
            P["B"][b] = hgb().fit(np.r_[Xv[a], Xs], np.r_[yv[a], ys]).predict(Xv[b])
            P["C"][b] = hgb().fit(np.c_[np.r_[Xv[a], Xs], np.r_[np.ones(len(a)), np.zeros(len(Xs))]], np.r_[yv[a], ys]).predict(np.c_[Xv[b], np.ones(len(b))])
        # oracle prior correction of the transported model (balanced training -> uniform implicit prior)
        full = np.zeros((len(V), K[t])); full[:, m.classes_.astype(int)] = pr
        tp = np.bincount(yv, minlength=K[t]) / len(yv); Por = full * tp; P["prior"] = Por.argmax(1)
        f = {k: macro_f1(yv, P[k]) for k in P}
        bs = []
        for _ in range(1000):
            i = rng.integers(0, len(yv), len(yv)); bs.append(macro_f1(yv[i], P["B"][i]) - macro_f1(yv[i], P["A"][i]))
        rows.append({"direction": nm, "task": t, "n_source": len(Src), "n_target": len(V), "F1_transported": f["X"], "F1_transported_true_prior": f["prior"],
                     "acc_transported": 100 * np.mean(P["X"] == yv), "within1_transported": 100 * np.mean(np.abs(P["X"] - yv) <= 1),
                     "F1_A_target_only": f["A"], "F1_B_target_plus_source": f["B"], "F1_C_plus_indicator": f["C"],
                     "B_minus_A": f["B"] - f["A"], "lo": np.percentile(bs, 2.5), "hi": np.percentile(bs, 97.5)})
        print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in rows[-1].items()}, flush=True)
        prev.append({"direction": nm, "task": t, **{f"src_g{k}": round(100 * np.mean(ys == k), 1) for k in range(K[t])}, **{f"tgt_g{k}": round(100 * np.mean(yv == k), 1) for k in range(K[t])}})
pd.DataFrame(rows).round(4).to_csv(os.path.join(OUT, "r18_temporal_decomposition.csv"), index=False)
pd.DataFrame(prev).to_csv(os.path.join(OUT, "r18_prevalence.csv"), index=False); print(pd.DataFrame(prev).to_string())
