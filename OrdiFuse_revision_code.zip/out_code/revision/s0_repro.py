import time, json
from ofx import *
df, info, tr, te = get_split()
print(info, len(tr), len(te))
S=["HAM4","ISI2","SleepTime","AD1","ISI1","AD7","AD2","HAM11","AD3","HAM14","HAM12","Hypertension","HAM10","ISI3","HAM8","HAM9","HAM6","HAM5","HAM13","HAM2","HAM7","HAM1","HAM3","ISI4"]
json.dump({"items":S},open(os.path.join(OUT,"s_star.json"),"w"))
D=df.iloc[tr].reset_index(drop=True); T=df.iloc[te].reset_index(drop=True); g=D["_profile_id"].values
Y={"insomnia":D["Insomnia"].values,"anxiety":D["Anxiety"].values}; Yt={"insomnia":T["Insomnia"].values,"anxiety":T["Anxiety"].values}
HYB5=(("HGB","ord"),("ET","ord"),("LR","ord"),("HGB","nom"),("ET","nom"))
t0=time.time()
m=OrdiFuse(S,bases=HYB5,meta="HGB",passthrough=True).fit(D,Y,g)
print("fit",time.time()-t0)
joblib.dump(m,os.path.join(CACHE,"of24_main.joblib"))
p,pr=m.predict_all(T)
joblib.dump((p,pr),os.path.join(CACHE,"of24_main_test.joblib"))
print({t:macro_f1(Yt[t],p[t]) for t in TASKS}, mt_f1(Yt,p))
