"""R2.5 decomposition of the internal-external performance drop (population vs. grading/concept shift).
Probe model: class-balanced HGB (default; Nominal) on all 51 items, fitted per task. Reporting only."""
import json
from scipy import stats
from sklearn.metrics import roc_auc_score, log_loss
from ofx import *
df, info = load_data(verbose=False)
TN = {"insomnia": "Insomnia", "anxiety": "Anxiety"}
occ = df["Occupation"] == 0; urb = df["Place_of_Education"] == 1; rur = df["Place_of_Education"] == 0
DIRS = [("Non-students → students", ~occ, occ), ("Students → non-students", occ, ~occ),
        ("Urban → rural", urb, rur), ("Rural → urban", rur, urb)]
DEFINING = ["Occupation", "EducationalYear", "UniversityType", "Place_of_Education"]
CLIN = ISI + HAMA + AD
rng = np.random.default_rng(SEED)

def fitpred(Dtr, Dte, t, w=None, feats=FEATURES):
    m = Nominal("HGB", feats, K[t], True)
    if w is None: m.fit(Dtr, Dtr[TN[t]].values)
    else:
        enc = make_encoder(feats).fit(Dtr[feats])
        from sklearn.utils.class_weight import compute_sample_weight
        sw = compute_sample_weight("balanced", Dtr[TN[t]].values) * w
        clf = HistGradientBoostingClassifier(learning_rate=0.1, max_leaf_nodes=31, l2_regularization=1.0, random_state=SEED)
        clf.fit(enc.transform(Dtr[feats]), Dtr[TN[t]].values, sample_weight=sw)
        P = clf.predict_proba(enc.transform(Dte[feats])); out = np.zeros((len(Dte), K[t]))
        for j, c in enumerate(clf.classes_): out[:, int(c)] = P[:, j]
        return out
    return m.proba(Dte)

def em_prior(P, prior_src, iters=200):
    """Saerens et al. (2002) EM re-estimation of target class priors; returns adjusted posteriors."""
    q = prior_src.copy()
    for _ in range(iters):
        A = P * (q / prior_src); A /= A.sum(1, keepdims=True); qn = A.mean(0)
        if np.abs(qn - q).max() < 1e-8: break
        q = qn
    return A, q

def oof_in_domain(V, t, feats=FEATURES):
    g = V["_profile_id"].values; P = np.zeros((len(V), K[t]))
    for a, b in inner_folds(V["Insomnia"].values, V["Anxiety"].values, g, 5, SEED):
        P[b] = Nominal("HGB", feats, K[t], True).fit(V.iloc[a].reset_index(drop=True), V[TN[t]].values[a]).proba(V.iloc[b].reset_index(drop=True))
    return P

rows, prev, conc = [], [], []
for name, sm, tm in DIRS:
    Dsrc = df[sm.values].reset_index(drop=True); V = df[tm.values].reset_index(drop=True)
    # covariate shift: domain classifier on non-defining items, grouped 5-fold OOF AUC
    feats_dom = [f for f in FEATURES if f not in DEFINING]
    Z = pd.concat([Dsrc, V]).reset_index(drop=True); dz = np.r_[np.zeros(len(Dsrc)), np.ones(len(V))]
    pd_oof = np.zeros(len(Z)); from sklearn.model_selection import StratifiedKFold
    for a, b in StratifiedKFold(5, shuffle=True, random_state=SEED).split(Z, dz):
        m = Pipeline([("e", make_encoder(feats_dom)), ("c", HistGradientBoostingClassifier(random_state=SEED))]).fit(Z.iloc[a][feats_dom], dz[a])
        pd_oof[b] = m.predict_proba(Z.iloc[b][feats_dom])[:, 1]
    auc_dom = roc_auc_score(dz, pd_oof)
    # clinical items only
    pc = np.zeros(len(Z))
    for a, b in StratifiedKFold(5, shuffle=True, random_state=SEED).split(Z, dz):
        m = HistGradientBoostingClassifier(random_state=SEED).fit(Z.iloc[a][CLIN], dz[a]); pc[b] = m.predict_proba(Z.iloc[b][CLIN])[:, 1]
    auc_clin = roc_auc_score(dz, pc)
    ps = np.clip(pd_oof[:len(Dsrc)], 0.01, 0.99); w = ps / (1 - ps) * len(Dsrc) / len(V); w = np.clip(w / w.mean(), 0.05, 20)
    ess = w.sum() ** 2 / (w ** 2).sum()
    for t in TASKS:
        ys, yv = Dsrc[TN[t]].values, V[TN[t]].values
        P_x = fitpred(Dsrc, V, t); f_x = macro_f1(yv, P_x.argmax(1))
        P_in = oof_in_domain(V, t); f_in = macro_f1(yv, P_in.argmax(1))
        P_src_cv = oof_in_domain(Dsrc, t); f_src = macro_f1(ys, P_src_cv.argmax(1))
        P_w = fitpred(Dsrc, V, t, w=w); f_w = macro_f1(yv, P_w.argmax(1))
        # label shift: balanced training => source "prior" seen by model is ~uniform
        pri_s = np.full(K[t], 1 / K[t])
        P_em, q = em_prior(P_x, pri_s); f_em = macro_f1(yv, P_em.argmax(1))
        tp = np.bincount(yv, minlength=K[t]) / len(yv)
        P_or = P_x * (tp / pri_s); P_or /= P_or.sum(1, keepdims=True); f_or = macro_f1(yv, P_or.argmax(1))
        # concept shift: disagreement between the source-trained and the target-trained (OOF) rule on the same target respondents
        dis = float(np.mean(P_x.argmax(1) != P_in.argmax(1)))
        # bootstrap CI of the transport gap (in-domain minus cross)
        bs = []
        for _ in range(500):
            i = rng.integers(0, len(yv), len(yv)); bs.append(macro_f1(yv[i], P_in.argmax(1)[i]) - macro_f1(yv[i], P_x.argmax(1)[i]))
        rows.append({"direction": name, "task": t, "n_source": len(Dsrc), "n_target": len(V),
                     "F1_source_inCV": f_src, "F1_target_inCV": f_in, "F1_transport": f_x,
                     "gap_target_in_minus_transport": f_in - f_x, "gap_lo": np.percentile(bs, 2.5), "gap_hi": np.percentile(bs, 97.5),
                     "F1_transport_cov_reweighted": f_w, "F1_transport_EM_prior": f_em, "F1_transport_oracle_prior": f_or,
                     "rule_disagreement_pct": 100 * dis, "domain_AUC_nondefining": auc_dom, "domain_AUC_clinical_items": auc_clin, "ESS_weights": ess})
        print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in rows[-1].items()}, flush=True)
        prev.append({"direction": name, "task": t, **{f"src_{k}": round(100 * np.mean(ys == k), 1) for k in range(K[t])},
                     **{f"tgt_{k}": round(100 * np.mean(yv == k), 1) for k in range(K[t])}})
    # identical clinical-item vectors shared across cohorts: are they graded the same?
    ks = Dsrc[CLIN].astype(str).agg("|".join, axis=1); kv = V[CLIN].astype(str).agg("|".join, axis=1)
    shared = set(ks) & set(kv)
    for t in TASKS:
        ms = Dsrc[ks.isin(shared)].assign(k=ks[ks.isin(shared)]).groupby("k")[TN[t]].agg(lambda s: s.mode().iloc[0])
        mv = V[kv.isin(shared)].assign(k=kv[kv.isin(shared)]).groupby("k")[TN[t]].agg(lambda s: s.mode().iloc[0])
        conc.append({"direction": name, "task": t, "shared_clinical_vectors": len(shared),
                     "pct_vectors_graded_differently_across_cohorts": round(100 * float(np.mean(ms.loc[list(shared)].values != mv.loc[list(shared)].values)), 2) if shared else np.nan})
pd.DataFrame(rows).round(4).to_csv(os.path.join(OUT, "r25_transport_decomposition.csv"), index=False)
pd.DataFrame(prev).to_csv(os.path.join(OUT, "r25_grade_prevalence.csv"), index=False)
pd.DataFrame(conc).to_csv(os.path.join(OUT, "r25_shared_vectors.csv"), index=False)
# pooled test of conditional shift: does a cohort indicator improve grouped-CV log-loss of P(grade | items)?
lr = []
for cname, ind in [("student", occ.astype(int)), ("urban", urb.astype(int))]:
    d = df.copy(); d["_ind"] = ind.values
    if cname == "urban": d = d[(urb | rur).values].reset_index(drop=True)
    g = d["_profile_id"].values
    for t in TASKS:
        base = [f for f in FEATURES if f not in DEFINING]
        L = {}
        for lab, feats in [("items", base), ("items + cohort", base + ["_ind"])]:
            P = np.zeros((len(d), K[t]))
            for a, b in inner_folds(d["Insomnia"].values, d["Anxiety"].values, g, 5, SEED):
                enc = make_encoder([f for f in feats if f != "_ind"]).fit(d.iloc[a][feats])
                Xa = np.c_[enc.transform(d.iloc[a][feats]), d["_ind"].values[a]] if "_ind" in feats else enc.transform(d.iloc[a][feats])
                Xb = np.c_[enc.transform(d.iloc[b][feats]), d["_ind"].values[b]] if "_ind" in feats else enc.transform(d.iloc[b][feats])
                m = HistGradientBoostingClassifier(random_state=SEED).fit(Xa, d[TN[t]].values[a])
                pp = m.predict_proba(Xb); P[b] = np.clip(pp, 1e-9, None)
            L[lab] = P
        y = d[TN[t]].values
        ll0 = -np.log(L["items"][np.arange(len(y)), y]); ll1 = -np.log(L["items + cohort"][np.arange(len(y)), y])
        diff = ll0 - ll1; se = diff.std(ddof=1) / np.sqrt(len(diff))
        lr.append({"cohort_indicator": cname, "task": t, "logloss_items": ll0.mean(), "logloss_items_plus_cohort": ll1.mean(),
                   "improvement": diff.mean(), "z": diff.mean() / se, "p_one_sided": stats.norm.sf(diff.mean() / se),
                   "f1_items": macro_f1(y, L["items"].argmax(1)), "f1_items_plus_cohort": macro_f1(y, L["items + cohort"].argmax(1))})
        print(lr[-1], flush=True)
pd.DataFrame(lr).round(5).to_csv(os.path.join(OUT, "r25_conditional_shift_test.csv"), index=False)
print("DONE")
