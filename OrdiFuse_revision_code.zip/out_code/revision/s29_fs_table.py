import json, glob
from ofx import *
df, info, tr, te = get_split(); T = df.iloc[te].reset_index(drop=True)
Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
subs = json.load(open(os.path.join(OUT, "r24_subsets.json"))); S = subs["Model-aware OrdiFuse permutation (S*)"]
key = lambda nm: "".join(c for c in nm if c.isalnum())[:40]
gt = T["_profile_id"].values; ug = np.unique(gt); gidx = {u: np.where(gt == u)[0] for u in ug}
rng = np.random.default_rng(SEED); GB = [np.concatenate([gidx[u] for u in rng.choice(ug, len(ug))]) for _ in range(2000)]
def mtb(p, i): return np.mean([macro_f1(Yt[t][i], p[t][i]) for t in TASKS])
P = {}
for nm in subs:
    P[("HGB", nm)] = joblib.load(os.path.join(CACHE, "fsev_hgb_" + key(nm) + ".joblib"))
    P[("OrdiFuse", nm)] = joblib.load(os.path.join(CACHE, "of24_main_test.joblib"))[0] if nm.startswith("Model-aware OrdiFuse") else joblib.load(os.path.join(CACHE, "fsev_of_" + key(nm) + ".joblib"))
ref = {L: P[(L, "Model-aware OrdiFuse permutation (S*)")] for L in ["OrdiFuse", "HGB"]}
rb = {L: np.array([mtb(ref[L], i) for i in GB]) for L in ref}
rows = []
for nm, fs in subs.items():
    r = {"method": nm, "overlap_with_S": len(set(fs) & set(S)), "not_in_S": ", ".join(sorted(set(fs) - set(S))), "missing_from_S": ", ".join(sorted(set(S) - set(fs)))}
    for L in ["OrdiFuse", "HGB"]:
        p = P[(L, nm)]; r[f"{L}_mt"] = mt_f1(Yt, p); r[f"{L}_ins"] = macro_f1(Yt["insomnia"], p["insomnia"]); r[f"{L}_anx"] = macro_f1(Yt["anxiety"], p["anxiety"])
        if not nm.startswith("Model-aware OrdiFuse"):
            d = rb[L] - np.array([mtb(p, i) for i in GB]); r[f"{L}_delta"] = mt_f1(Yt, ref[L]) - r[f"{L}_mt"]; r[f"{L}_lo"], r[f"{L}_hi"] = np.percentile(d, [2.5, 97.5])
    rows.append(r); print(nm, round(r["OrdiFuse_mt"], 4), round(r["HGB_mt"], 4), flush=True)
R = pd.DataFrame(rows); R.round(4).to_csv(os.path.join(OUT, "r24_fs_table.csv"), index=False); print(R.round(4).to_string())
