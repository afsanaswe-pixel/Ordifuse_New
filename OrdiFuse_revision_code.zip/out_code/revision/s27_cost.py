"""R1.3 model-level computational cost on the locked test set: training time, inference latency, serialized size,
and two model-level compression probes: (a) knowledge distillation of OrdiFuse into one class-balanced HGB per task
trained on OrdiFuse's out-of-fold grades for the training partition; (b) post-training symmetric per-channel int8
weight quantization of the neural multitask MLP (in the spirit of PTQ methods such as DARE-Q)."""
import json, time, pickle, io
from ofx import *
df, info, tr, te = get_split()
D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True); g = D["_profile_id"].values
Y = {"insomnia": D["Insomnia"].values, "anxiety": D["Anxiety"].values}; Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
HYB5 = (("HGB", "ord"), ("ET", "ord"), ("LR", "ord"), ("HGB", "nom"), ("ET", "nom"))
def size_mb(obj):
    b = io.BytesIO(); joblib.dump(obj, b, compress=3); return len(b.getvalue()) / 1e6
def latency(fn, X, reps=3):
    one = X.iloc[[0]]; t = []
    for _ in range(reps): t0 = time.perf_counter(); fn(one); t.append(time.perf_counter() - t0)
    t0 = time.perf_counter(); fn(X); batch = time.perf_counter() - t0
    return 1000 * np.median(t), 1000 * batch / len(X)
rows = []
def record(name, fit_s, model, fn, pred):
    l1, lb = latency(fn, T)
    rows.append({"model": name, "fit_s": fit_s, "size_MB_compressed": size_mb(model), "latency_single_ms": l1, "latency_batch_ms_per_resp": lb,
                 "f1_ins": macro_f1(Yt["insomnia"], pred["insomnia"]), "f1_anx": macro_f1(Yt["anxiety"], pred["anxiety"]), "f1_mt": mt_f1(Yt, pred)})
    print(rows[-1], flush=True)
# OrdiFuse 24
m = joblib.load(os.path.join(CACHE, "of24_main.joblib"))
t0 = time.time(); OrdiFuse(S, bases=HYB5, meta="HGB", passthrough=True).fit(D, Y, g); fit = time.time() - t0
record("OrdiFuse (24)", fit, m, lambda X: m.predict_all(X), m.predict_all(T)[0])
nb = {t: sum(len(b.m_) if hasattr(b, "m_") and isinstance(b.m_, list) else 1 for b in m.base_[t]) for t in TASKS}
print("fitted level-0 estimators per task", nb, flush=True)
# class-balanced HGB 24
t0 = time.time(); h = {t: Nominal("HGB", S, K[t], True).fit(D, Y[t]) for t in TASKS}; fit = time.time() - t0
record("HGB class-balanced (24)", fit, h, lambda X: {t: h[t].proba(X) for t in TASKS}, {t: h[t].proba(T).argmax(1) for t in TASKS})
# stacking comparator
t0 = time.time(); st = {t: OOFStack(["LR", "HGB", "RF"], "HGB", S, K[t]).fit(D, Y[t], g) for t in TASKS}; fit = time.time() - t0
record("Stacking comparator (24)", fit, st, lambda X: {t: st[t].predict_proba(X) for t in TASKS}, {t: st[t].predict(T) for t in TASKS})
# (a) distillation: student HGB trained on OrdiFuse meta OOF probabilities -> OOF grades (with OrdiFuse offsets)
lab = {t: (np.log(np.clip(m.meta_oof_[t], 1e-9, None)) + m.off_[t]).argmax(1) for t in TASKS}
t0 = time.time(); stu = {t: Nominal("HGB", S, K[t], True).fit(D, lab[t]) for t in TASKS}; fit = time.time() - t0
record("Distilled student: one HGB per task (24)", fit, stu, lambda X: {t: stu[t].proba(X) for t in TASKS}, {t: stu[t].proba(T).argmax(1) for t in TASKS})
# (b) int8 PTQ of the neural MT-MLP
try:
    from nnmt import NeuralMT
    import jax, jax.numpy as jnp
    tun = joblib.load(os.path.join(CACHE, "nn_tune_MT-MLP-CUM.joblib")); ev = joblib.load(os.path.join(CACHE, "nn_eval_MT-MLP-CUM.joblib"))
    F5 = inner_folds(Y["insomnia"], Y["anxiety"], g, 5, SEED + 100)
    off = {t: tune_offsets(ev["oof"][t], Y[t]) for t in TASKS}
    t0 = time.time(); nn = NeuralMT(S, arch="mlp", kind="cum", fixed_epochs=tun["epochs"], **tun["cfg"]).fit(D, Y, g); fit = time.time() - t0
    def predo(model, X): pr = model.proba(X); return {t: (np.log(pr[t]) + off[t]).argmax(1) for t in TASKS}
    p32 = predo(nn, T)
    nbytes32 = sum(np.asarray(x).nbytes for x in jax.tree_util.tree_leaves(nn.p_))
    rows.append({"model": "Neural MT-MLP-CUM float32 (24)", "fit_s": fit, "size_MB_compressed": nbytes32 / 1e6, "f1_ins": macro_f1(Yt["insomnia"], p32["insomnia"]),
                 "f1_anx": macro_f1(Yt["anxiety"], p32["anxiety"]), "f1_mt": mt_f1(Yt, p32), "latency_batch_ms_per_resp": latency(lambda X: nn.proba(X), T)[1],
                 "latency_single_ms": latency(lambda X: nn.proba(X), T)[0]})
    def q8(W):
        W = np.asarray(W)
        if W.ndim < 2: return W, W.nbytes
        s = np.abs(W).max(0, keepdims=True) / 127 + 1e-12; Q = np.round(W / s).clip(-127, 127).astype(np.int8)
        return (Q.astype(np.float32) * s), Q.nbytes + s.astype(np.float32).nbytes
    leaves, tdef = jax.tree_util.tree_flatten(nn.p_); new, nb8 = [], 0
    for L in leaves: w, b = q8(L); new.append(jnp.asarray(w, dtype=jnp.float32)); nb8 += b
    nn.p_ = jax.tree_util.tree_unflatten(tdef, new); p8 = predo(nn, T)
    agree = np.mean([np.mean(p8[t] == p32[t]) for t in TASKS])
    rows.append({"model": "Neural MT-MLP-CUM int8 PTQ (24)", "fit_s": np.nan, "size_MB_compressed": nb8 / 1e6, "f1_ins": macro_f1(Yt["insomnia"], p8["insomnia"]),
                 "f1_anx": macro_f1(Yt["anxiety"], p8["anxiety"]), "f1_mt": mt_f1(Yt, p8), "agreement_with_fp32_pct": 100 * agree})
    print(rows[-2:], flush=True)
except Exception as e:
    print("NN cost skipped:", e)
pd.DataFrame(rows).round(4).to_csv(os.path.join(OUT, "r13_cost.csv"), index=False); print(pd.DataFrame(rows).round(4).to_string()); print("DONE")
