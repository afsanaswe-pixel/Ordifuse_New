"""R1.8 leave-one-event-out validation with class-balanced HGB on the 24 items of S* (cheap probe; OrdiFuse is
evaluated on the temporal and venue splits). Each event is held out in turn; the model is trained on the other 22."""
import json
from ofx import *
df, info = load_data(verbose=False)
X = pd.read_csv("/home/claude/rev/ev/extra.csv"); df["Event"] = X["Event_ID"].values
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
rows = []
for e in [f"E{i}" for i in range(1, 24)]:
    m = (df.Event == e).values; D = df[~m].reset_index(drop=True); T = df[m].reset_index(drop=True)
    p = {t: Nominal("HGB", S, K[t], True).fit(D, D[c].values).proba(T).argmax(1) for t, c in [("insomnia", "Insomnia"), ("anxiety", "Anxiety")]}
    yi, ya = T.Insomnia.values, T.Anxiety.values
    rows.append({"event": e, "n": int(m.sum()), "acc_ins": 100 * np.mean(p["insomnia"] == yi), "acc_anx": 100 * np.mean(p["anxiety"] == ya),
                 "joint_exact": 100 * np.mean((p["insomnia"] == yi) & (p["anxiety"] == ya)),
                 "f1_ins": macro_f1(yi, p["insomnia"]), "f1_anx": macro_f1(ya, p["anxiety"]),
                 "n_ins_grades": len(np.unique(yi)), "n_anx_grades": len(np.unique(ya))})
    print(rows[-1], flush=True)
R = pd.DataFrame(rows); R.round(4).to_csv(os.path.join(OUT, "r18_loeo.csv"), index=False)
w = R.n / R.n.sum()
print("pooled acc ins", (w * R.acc_ins).sum(), "anx", (w * R.acc_anx).sum(), "joint", (w * R.joint_exact).sum(), "range joint", R.joint_exact.min(), R.joint_exact.max())
