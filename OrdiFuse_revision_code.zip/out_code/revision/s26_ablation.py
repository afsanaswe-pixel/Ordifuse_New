"""R2.3 / R1.4 component ablations of OrdiFuse on S* (each row removes or swaps ONE component of the published
design), evaluated on the locked test set and on the three new profile-grouped splits (seeds 101-103) used for the
repeated re-derivation. S* is held fixed so that every variant sees the same items (paired comparison).
Also 'fusion stress tests': cross-task fusion with/without the item passthrough and with one instrument removed."""
import json, sys, time
from ofx import *
df, info = load_data(verbose=False)
S = json.load(open(os.path.join(OUT, "s_star.json")))["items"]
ORD3 = (("HGB", "ord"), ("ET", "ord"), ("LR", "ord")); NOM2 = (("HGB", "nom"), ("ET", "nom")); HYB5 = ORD3 + NOM2
FULL = dict(bases=HYB5, meta="HGB", passthrough=True, fusion=True, tune=True)
VARS = {
 "A OrdiFuse (published)": (S, FULL),
 "B − cross-task fusion": (S, {**FULL, "fusion": False}),
 "C − item passthrough": (S, {**FULL, "passthrough": False}),
 "D − fusion − passthrough (plain ordinal+nominal stack)": (S, {**FULL, "fusion": False, "passthrough": False}),
 "E − nominal level-0 learners (ordinal only)": (S, {**FULL, "bases": ORD3}),
 "F − ordinal level-0 learners (nominal only)": (S, {**FULL, "bases": NOM2}),
 "G − class weighting": (S, {**FULL, "balanced": False}),
 "H − decision offsets": None,   # A's probabilities, arg-max without offsets
 "I LR meta-learner instead of HGB": (S, {**FULL, "meta": "LR"}),
 "J isotonic calibration layer added": (S, {**FULL, "calibrate": True}),
 # fusion stress tests
 "S1 without ISI items, with fusion": ([f for f in S if f not in ISI], FULL),
 "S2 without ISI items, no fusion": ([f for f in S if f not in ISI], {**FULL, "fusion": False}),
 "S3 without HAM-A items, with fusion": ([f for f in S if f not in HAMA], FULL),
 "S4 without HAM-A items, no fusion": ([f for f in S if f not in HAMA], {**FULL, "fusion": False}),
}
codes = joint_codes(df["Insomnia"], df["Anxiety"]); G = df["_profile_id"].values
SPLITS = [("main", None)] + [(f"rep{r+1}", s) for r, s in enumerate([101, 102, 103])]
which = sys.argv[1:] or [s for s, _ in SPLITS]
key = lambda nm: "".join(c if c.isalnum() else "_" for c in nm)[:50]
for sname, seed in SPLITS:
    if sname not in which: continue
    if seed is None: _, _, tr, te = get_split()
    else: tr, te = grouped_split(len(df), codes, G, 0.20, seed)
    D = df.iloc[tr].reset_index(drop=True); T = df.iloc[te].reset_index(drop=True); g = D["_profile_id"].values
    Y = {"insomnia": D["Insomnia"].values, "anxiety": D["Anxiety"].values}
    for vn, spec in VARS.items():
        if spec is None: continue
        if sname != "main" and vn[0] in "SIJFG": continue
        feats, kw = spec; t0 = time.time()
        if sname == "main" and vn.startswith("A "):
            r = joblib.load(os.path.join(CACHE, "of24_main_test.joblib")); m = None
        else:
            r = cached(f"abl_{sname}_{key(vn)}", lambda feats=feats, kw=kw: OrdiFuse(feats, **kw).fit(D, Y, g).predict_all(T))
        Yt = {"insomnia": T["Insomnia"].values, "anxiety": T["Anxiety"].values}
        print(f"{sname} {vn:<55s} ins {macro_f1(Yt['insomnia'], r[0]['insomnia']):.4f} anx {macro_f1(Yt['anxiety'], r[0]['anxiety']):.4f} mt {mt_f1(Yt, r[0]):.4f} ({time.time()-t0:.0f}s)", flush=True)
print("DONE")
